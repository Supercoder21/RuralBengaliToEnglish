# Rural Bengali Dialect → English: Linguistic Divergence Project

**Students:** Avnish & Aarav
**Assignments:** Assignment 1 (GloVe & Word2Vec) + Assignment 2 (NLP Fundamentals)

## Repository Structure

```
rural_bengali_en/
├── data/
│   ├── corpus_A/corpus_a.txt     # 874 sentences, Purulia dialect, ITRANS
│   └── corpus_B/corpus_b.txt     # 9,993 sentences, standard Bengali, ITRANS
├── embeddings/
│   ├── sgns.py                   # Avnish — Task 1: SGNS from scratch
│   ├── data_utils.py             # Vocab, encoding, alias sampler
│   └── sgns_embeddings_*.npy     # Trained embeddings (joint, DA, DB)
├── alignment/
│   └── eval_divergence.py        # Task 3 + 4 + 5: overlap, Procrustes, JS
├── metrics/
│   ├── levenshtein.py            # Avnish — A2 Part I
│   └── bleu.py                   # Avnish — A2 Part V
├── model/
│   └── attention.py              # Avnish — A2 Part III
├── scripts/
│   ├── asr_pipeline.py           # Audio → Whisper → ITRANS pipeline
│   └── scrape_dialect_audio.py   # YouTube audio scraper
├── asr_writeup.md                # ASR system documentation
├── task1_report.md               # SGNS report
├── CHANGELOG.md                  # Development log
└── requirements.txt
```

## Quick Start

```bash
pip install -r requirements.txt

# Reproduce SGNS
cd embeddings && python sgns.py --corpus-a ../data/corpus_A/corpus_a.txt --corpus-b ../data/corpus_B/corpus_b.txt

# Run divergence analysis
cd alignment && python eval_divergence.py

# Run BLEU tests
cd metrics && python bleu.py

# Run Levenshtein tests
cd metrics && python levenshtein.py

# Run attention tests
cd model && python attention.py
```
