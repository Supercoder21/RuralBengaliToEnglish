# CHANGELOG — Assignment 1, Task 1 (SGNS)

## Session Timeline

### Phase 1: Architecture Review & Pipeline Design

**Reviewed existing codebase (`untitled7.py`)**
- File contained: `data_utils.py` (commented out), GloVe implementation (commented out), `task4.py` (Procrustes alignment, active code)
- No SGNS model existed — only the infrastructure (alias sampler, vocab builder, subsampling, pair generator)
- Decision: salvage `data_utils` infrastructure, build `sgns.py` from scratch
- Identified tokenizer incompatibility: existing regex (`[a-z']+`) is English-only

**Designed ASR + Transliteration pipeline**
- Chose ITRANS romanisation scheme (lowercase ASCII, consistent mapping)
- Tested `indic-transliteration` library on Bengali script → verified ব→v, মাটি→mati, নৌকা→nauka
- Identified stray Unicode leak issue (nukta ়) in transliteration — added `_STRAY_UNICODE` regex strip
- Compared ITRANS vs IAST vs HK vs KOLKATA schemes — selected ITRANS (lowercased) for ASCII-only output

### Phase 2: Corpus Sourcing

**DB (Standard Bengali):** Identified OpenSLR-53 (openslr.org/53) — ~196K utterances, CC BY-SA 4.0, pre-transcribed in Bengali script TSV. No audio download needed for DB.

**DA (Rural Bengali Dialect):** Evaluated multiple options:
- Bengali.AI Regional Dialect ASR (Hugging Face) — promising but unclear single-dialect access
- RegSpeech12 (arXiv 2510.24096) — too new, data availability uncertain
- BanglaDial (60K sentences, 11 dialects) — text-only, user required audio
- ONUBAD (Chittagong/Sylhet/Barisal parallel corpus) — too small (980 sentences/dialect)
- **Final decision:** YouTube scraping of Purulia/Manbhumi dialect long-form content

**Selected dialect: Manbhumi (Western Bengali)** — strongest lexical divergence from standard Bengali due to Hindi/Odia substrate. Well-documented shifts (ছেলে→পো, লোক→নোক).

### Phase 3: Pipeline Implementation

**Created `asr_pipeline.py`**
- Three input pathways: Whisper on audio, transliterate pre-existing text, or download+transliterate OpenSLR-53
- Bengali → ITRANS → lowercase → strip non-ASCII → collapse whitespace
- Quality filter: min 3 tokens per sentence, min 3 Bengali characters per line
- Saves raw Bengali alongside romanised output for reference
- CLI with `--skip-da`, `--skip-db`, `--whisper-model`, `--max-db-sentences` flags

**Created `scrape_dialect_audio.py`**
- yt-dlp wrapper for downloading long-form audio
- Auto-converts to 16kHz mono WAV (Whisper input format)
- Duration filter: skips clips <2min or >2hr
- Search mode (yt-dlp YouTube search) and URL list mode
- Includes curated Bengali search queries for Purulia/Manbhumi content

**Created `data_utils.py`**
- Rewired from English synthetic corpus to romanised Bengali
- Tokenizer: `re.findall(r"[a-z]+")` on ITRANS output
- Probe word candidates: vajara, mati, nauka, dhana, goru, hata, nadi, macha, chasha, grama
- Fallback probe selector for when candidates don't appear in actual vocab

**Created `requirements.txt`**

### Phase 4: User's Local Execution

**Audio scraping (user's machine, Windows):**
- Resolved yt-dlp PATH issue (installed but not on PATH)
- Resolved ffmpeg missing error (installed via `winget install Gyan.FFmpeg`, then added to PATH)
- Successfully downloaded 8 Purulia dialect videos: 296 minutes total, 0.57 GB

**Whisper ASR (user's machine):**
- First attempt: large-v3 model download failed (SHA256 checksum mismatch) — deleted cached model, retried
- GPU not utilised (torch.cuda not available) — ran on CPU
- Completed in ~12 hours on CPU
- Produced `corpus_a.txt`: 1,006 sentences

**DB pipeline (user's machine):**
- Downloaded OpenSLR-53 TSV (15MB)
- Transliterated 153,559 sentences → `corpus_b.txt`

### Phase 5: Corpus Analysis & Cleaning

**DA analysis:**
- 1,006 sentences, 7,950 tokens, 3,195 types — small but genuine Purulia dialect
- Identified noise: "pragrama karechana" (25×), "sailaho vartara" (15×) — channel intros
- Deduplicated: removed ~130 duplicate lines
- Stripped 3 channel noise patterns
- **Cleaned DA:** 874 sentences, 7,225 tokens

**DB subsampling:**
- Raw: 153,559 sentences — 100:1 ratio would drown dialect signal
- Subsampled to 10,000 sentences (random, seed=42) — 11:1 ratio

**Vocabulary overlap analysis:**
- 702 types shared between DA and DB
- 207 types with freq≥3 in both — the effective shared vocabulary for analysis
- 2,155 DA-only types (dialect-specific vocabulary)

### Phase 6: SGNS Implementation & Training

**Created `sgns.py`**
- `SGNSModel` class: V and U matrices, numerically stable sigmoid, train_pair with full gradient computation
- Adam optimizer: per-parameter moment tracking for target, context, and each negative
- `train_sgns`: epoch loop with stochastic subsampling, sentence shuffling, progress logging
- `plot_loss_curves`: matplotlib output for all models
- `print_and_save_neighbours`: probe word analysis across all models

**Training run 1 (t=10⁻⁵):**
- Only 2,933 pairs per epoch — subsampling removed 95% of tokens
- Loss barely decreased (4.16→4.09 over 5 epochs)
- Neighbour similarities all >0.99 — embeddings undifferentiated
- **Diagnosis:** subsampling threshold too aggressive for small corpus

**Training run 2 (t=10⁻⁴):**
- 24K pairs per epoch (8× more)
- Loss converges properly: Joint 4.05→2.60, DA 4.13→1.48, DB 4.12→2.60
- Neighbour tables show clear DA/DB divergence
- DA probes pull up dialect-specific vocabulary (jumara, karite, vavu)
- **This is the final run.**

### Phase 7: Report & Deliverables

- Generated loss curve figure (3 models overlaid)
- Generated neighbour tables (10 probes × 3 models × 10 neighbours)
- Saved embeddings as .npy (joint, DA, DB)
- Saved vocab mapping and hyperparameters as JSON
- Created this report and changelog

## Files Produced

```
sgns.py                          SGNS model, training loop, CLI
data_utils.py                    Vocab, encoding, alias sampler, subsampling
asr_pipeline.py                  Audio → Whisper → ITRANS pipeline
scrape_dialect_audio.py          YouTube audio scraper
corpus_a.txt                     DA — 874 sentences, Purulia dialect
corpus_b.txt                     DB — 9,993 sentences, standard Bengali
outputs/sgns_loss_curve.png      Training curves (3 models)
outputs/sgns_neighbours.txt      Probe word neighbour tables
outputs/sgns_embeddings_joint.npy Joint embeddings (3022 × 100)
outputs/sgns_embeddings_a.npy    DA embeddings (3022 × 100)
outputs/sgns_embeddings_b.npy    DB embeddings (3022 × 100)
outputs/sgns_vocab.json          word2idx, probes, hyperparams, corpus stats
task1_report.md                  This report
CHANGELOG.md                     This changelog
```

## Key Decisions Log

| Decision | Alternatives Considered | Rationale |
|---|---|---|
| ITRANS romanisation | IAST, HK, Kolkata | ASCII-only, no diacritics, consistent mapping |
| Manbhumi dialect | Sylheti, Chittagong, Rangpuri | Strongest lexical divergence from standard Bengali |
| YouTube scraping for DA | BanglaDial (text), Bengali.AI (unclear access) | User required audio source specifically |
| t=10⁻⁴ subsampling | t=10⁻⁵ (roadmap spec) | 10⁻⁵ removes 95% of tokens from small corpus |
| min_freq=3 | min_freq=5 (roadmap spec) | freq≥5 leaves only 274 DA types — too few |
| DB subsampled to 10K | Full 153K, or matched 874 | 11:1 ratio balances signal without drowning DA |
| 30 epochs for DA | 5 or 10 | Small corpus needs more passes to converge |
| Function-word probes | Rural content words (roadmap) | Content words too infrequent in small DA corpus |
