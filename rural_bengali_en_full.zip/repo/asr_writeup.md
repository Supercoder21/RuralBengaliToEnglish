# ASR System: Audio → Transliterated Text

*Section for the joint report (README.pdf). Author: Avnish.*

## Pipeline Overview

The ASR subsystem converts raw audio input in rural Bengali dialect into tokenised, romanised text suitable for downstream embedding training and translation. The pipeline has four stages:

```
Audio (WAV/MP3)  →  Whisper ASR  →  Bengali Script  →  ITRANS Roman  →  corpus.txt
     ↑                  ↑                                    ↑
  yt-dlp            large-v3                          indic-transliteration
  16kHz mono        language=bn                       lowercase ASCII
```

## Stage 1: Audio Acquisition

Rural Bengali dialect audio was sourced from YouTube using yt-dlp. Eight long-form videos (interviews, folk artist conversations, local cultural programming) in the Purulia/Manbhumi dialect of western Bengal were downloaded. Videos were filtered by duration (minimum 2 minutes, maximum 2 hours) and converted to 16kHz mono WAV.

**Total audio:** 8 files, 296 minutes (~5 hours), 0.57 GB.

## Stage 2: Automatic Speech Recognition

OpenAI Whisper large-v3 was used for ASR with language="bn" (Bengali) and task="transcribe". Whisper's internal VAD segments continuous audio into sentence-level chunks automatically.

## Stage 3: Transliteration

Bengali script was converted to ITRANS romanisation (lowercase ASCII) using the indic-transliteration Python library.

## Stage 4: Quality Filtering

Sentences with fewer than 3 tokens after romanisation were discarded. Duplicate lines and channel intro noise removed.

**Final DA corpus:** 874 sentences, 7,225 tokens, 3,195 unique types.

## Standard Bengali Corpus (DB)

OpenSLR-53 (~196K utterances of standard Bangladeshi Bengali, CC BY-SA 4.0). Only transliteration applied. Subsampled to 10,000 sentences.

## Reproducibility

```bash
pip install openai-whisper indic-transliteration yt-dlp tqdm requests
python scripts/scrape_dialect_audio.py --url-file urls.txt --output-dir data/dialect_audio
python scripts/asr_pipeline.py --da-audio-dir data/dialect_audio --output-dir data --whisper-model large-v3
```
