"""
sgns.py
-------
Word2Vec Skip-Gram with Negative Sampling (SGNS) — from scratch.

Assignment 1, Task 1 — Avnish (Lead Owner)

Architecture
------------
  • Input embedding matrix  V_w ∈ R^{|V| × d}  (target words)
  • Output embedding matrix U_w ∈ R^{|V| × d}  (context words)
  • Loss per positive pair (w, c) with k negatives {n_1,...,n_k}:
      L = -log σ(u_c^T v_w) - Σ_{i=1}^{k} log σ(-u_{n_i}^T v_w)
  • Optimizer: Adam (η = 5×10⁻⁴)
  • Final embedding: e_w = (v_w + u_w) / 2

Hyperparameters (per roadmap)
-----------------------------
  d = 100       embedding dimension
  W = 5         max context window (random ∈ {1,...,W})
  k = 5         negative samples per positive pair
  t = 10⁻⁵      subsampling threshold
  η = 5×10⁻⁴    learning rate (Adam)
  P_neg ∝ f(w)^{3/4}   negative sampling distribution

Usage
-----
  python sgns.py --corpus-a corpus_a.txt --corpus-b corpus_b.txt

Deliverables
------------
  • sgns.py                     (this file)
  • outputs/sgns_loss_curve.png
  • outputs/sgns_neighbours.txt
  • outputs/sgns_embeddings_joint.npy
  • outputs/sgns_embeddings_a.npy
  • outputs/sgns_embeddings_b.npy

Authors: Avnish (embeddings & metrics lead)
"""

import os
import time
import random
import argparse
import numpy as np
from collections import Counter
from typing import List, Dict, Tuple, Optional

from data_utils import (
    load_corpus, build_vocab, encode_corpus,
    build_subsample_probs, subsample_corpus,
    AliasSampler, iter_skipgram_pairs,
    PAD_TOKEN, UNK_TOKEN,
)


# ═══════════════════════════════════════════════════════════════════════════
# SGNS Model
# ═══════════════════════════════════════════════════════════════════════════

class SGNSModel:
    """
    Skip-Gram with Negative Sampling — pure NumPy implementation.

    Parameters
    ----------
    vocab_size : int
    dim : int
        Embedding dimension (d = 100 per roadmap)
    seed : int
        Random seed for reproducibility
    """

    def __init__(self, vocab_size: int, dim: int = 100, seed: int = 42):
        rng = np.random.default_rng(seed)
        scale = 0.5 / dim

        # Embedding matrices: small uniform init
        self.V = rng.uniform(-scale, scale, (vocab_size, dim)).astype(np.float32)  # input/target
        self.U = rng.uniform(-scale, scale, (vocab_size, dim)).astype(np.float32)  # output/context

        self.vocab_size = vocab_size
        self.dim = dim

        # Adam state
        self._m_V = np.zeros_like(self.V)
        self._v_V = np.zeros_like(self.V)
        self._m_U = np.zeros_like(self.U)
        self._v_U = np.zeros_like(self.U)
        self._t = 0  # timestep counter

    @staticmethod
    def _sigmoid(x: np.ndarray) -> np.ndarray:
        """Numerically stable sigmoid."""
        return np.where(
            x >= 0,
            1.0 / (1.0 + np.exp(-x)),
            np.exp(x) / (1.0 + np.exp(x)),
        )

    def train_pair(
        self,
        target: int,
        context: int,
        negatives: np.ndarray,
        lr: float = 5e-4,
        beta1: float = 0.9,
        beta2: float = 0.999,
        eps: float = 1e-8,
    ) -> float:
        """
        Train on one (target, context) pair with negative samples.

        Loss = -log σ(u_c · v_w) - Σ log σ(-u_{n_i} · v_w)

        Returns the scalar loss for this pair.
        """
        v_w = self.V[target]  # (d,)

        # ── Positive pair ──
        u_c = self.U[context]  # (d,)
        dot_pos = np.dot(u_c, v_w)
        sig_pos = self._sigmoid(dot_pos)
        loss = -np.log(sig_pos + 1e-12)

        # Gradient: ∂L/∂v_w += -(1 - σ(u_c·v_w)) * u_c
        #           ∂L/∂u_c  = -(1 - σ(u_c·v_w)) * v_w
        grad_v = -(1.0 - sig_pos) * u_c
        grad_u_c = -(1.0 - sig_pos) * v_w

        # ── Negative samples ──
        u_neg = self.U[negatives]  # (k, d)
        dots_neg = u_neg @ v_w     # (k,)
        sig_neg = self._sigmoid(dots_neg)  # (k,)
        loss += -np.sum(np.log(1.0 - sig_neg + 1e-12))

        # Gradient: ∂L/∂v_w += Σ σ(u_{n_i}·v_w) * u_{n_i}
        #           ∂L/∂u_{n_i} = σ(u_{n_i}·v_w) * v_w
        grad_v += sig_neg @ u_neg  # (d,)
        grad_u_neg = np.outer(sig_neg, v_w)  # (k, d)

        # ── Adam update ──
        self._t += 1
        t = self._t

        # Update V[target]
        self._m_V[target] = beta1 * self._m_V[target] + (1 - beta1) * grad_v
        self._v_V[target] = beta2 * self._v_V[target] + (1 - beta2) * grad_v**2
        m_hat = self._m_V[target] / (1 - beta1**t)
        v_hat = self._v_V[target] / (1 - beta2**t)
        self.V[target] -= lr * m_hat / (np.sqrt(v_hat) + eps)

        # Update U[context]
        self._m_U[context] = beta1 * self._m_U[context] + (1 - beta1) * grad_u_c
        self._v_U[context] = beta2 * self._v_U[context] + (1 - beta2) * grad_u_c**2
        m_hat = self._m_U[context] / (1 - beta1**t)
        v_hat = self._v_U[context] / (1 - beta2**t)
        self.U[context] -= lr * m_hat / (np.sqrt(v_hat) + eps)

        # Update U[negatives]
        for idx_i, neg_i in enumerate(negatives):
            g = grad_u_neg[idx_i]
            self._m_U[neg_i] = beta1 * self._m_U[neg_i] + (1 - beta1) * g
            self._v_U[neg_i] = beta2 * self._v_U[neg_i] + (1 - beta2) * g**2
            m_hat = self._m_U[neg_i] / (1 - beta1**t)
            v_hat = self._v_U[neg_i] / (1 - beta2**t)
            self.U[neg_i] -= lr * m_hat / (np.sqrt(v_hat) + eps)

        return float(loss)

    def get_embeddings(self, normalize: bool = True) -> np.ndarray:
        """
        Final embedding: e_w = (v_w + u_w) / 2
        Averaging reduces anisotropy (per roadmap specification).
        """
        E = (self.V + self.U) / 2.0
        if normalize:
            norms = np.linalg.norm(E, axis=1, keepdims=True)
            norms = np.maximum(norms, 1e-12)
            E = E / norms
        return E

    def nearest_neighbors(
        self,
        word: str,
        word2idx: Dict[str, int],
        idx2word: Dict[int, str],
        top_n: int = 10,
    ) -> List[Tuple[str, float]]:
        """Return top_n nearest neighbours by cosine similarity."""
        if word not in word2idx:
            return []
        E = self.get_embeddings(normalize=True)
        query = E[word2idx[word]]
        sims = E @ query
        sims[word2idx[word]] = -2.0  # exclude self
        # Also exclude PAD and UNK
        sims[0] = -2.0
        sims[1] = -2.0
        top = np.argpartition(sims, -top_n)[-top_n:]
        top = top[np.argsort(sims[top])[::-1]]
        return [(idx2word[i], float(sims[i])) for i in top]


# ═══════════════════════════════════════════════════════════════════════════
# Training Loop
# ═══════════════════════════════════════════════════════════════════════════

def train_sgns(
    model: SGNSModel,
    encoded_corpus: List[List[int]],
    keep_probs: np.ndarray,
    neg_sampler: AliasSampler,
    epochs: int = 5,
    k: int = 5,
    W: int = 5,
    lr: float = 5e-4,
    seed: int = 42,
    log_every: int = 5000,
    label: str = "",
) -> List[Tuple[int, float]]:
    """
    Train SGNS for multiple epochs.

    Returns
    -------
    curve : list of (step, avg_loss) tuples for plotting
    """
    rng = np.random.default_rng(seed)
    curve = []
    global_step = 0
    running_loss = 0.0
    running_count = 0

    for epoch in range(1, epochs + 1):
        t0 = time.time()

        # Subsample corpus each epoch (stochastic)
        subsampled = subsample_corpus(encoded_corpus, keep_probs, rng)

        # Shuffle sentence order
        rng.shuffle(subsampled)

        epoch_loss = 0.0
        epoch_pairs = 0

        for target, context in iter_skipgram_pairs(subsampled, W=W, rng=rng):
            # Sample negatives
            negatives = neg_sampler.sample(k, rng)

            # Ensure negatives don't include target or context
            # (simple rejection — rare enough to not matter)
            mask = (negatives != target) & (negatives != context)
            negatives = negatives[mask]
            if len(negatives) < k:
                extra = neg_sampler.sample(k, rng)
                negatives = np.concatenate([negatives, extra])[:k]

            loss = model.train_pair(target, context, negatives, lr=lr)
            epoch_loss += loss
            epoch_pairs += 1
            global_step += 1
            running_loss += loss
            running_count += 1

            if global_step % log_every == 0:
                avg = running_loss / running_count
                curve.append((global_step, avg))
                running_loss = 0.0
                running_count = 0

        elapsed = time.time() - t0
        avg_epoch_loss = epoch_loss / max(epoch_pairs, 1)
        print(f"  [{label}] Epoch {epoch}/{epochs}  "
              f"pairs={epoch_pairs:,}  loss={avg_epoch_loss:.4f}  "
              f"time={elapsed:.1f}s")

        # Also record end-of-epoch
        curve.append((global_step, avg_epoch_loss))

    return curve


# ═══════════════════════════════════════════════════════════════════════════
# Plotting
# ═══════════════════════════════════════════════════════════════════════════

def plot_loss_curves(
    curves: Dict[str, List[Tuple[int, float]]],
    output_path: str,
):
    """Plot loss-vs-step curves for all trained models."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(10, 5))

    colors = ['#2196F3', '#FF5722', '#4CAF50']
    for i, (label, curve) in enumerate(curves.items()):
        steps = [s for s, _ in curve]
        losses = [l for _, l in curve]
        ax.plot(steps, losses, linewidth=2, label=label,
                color=colors[i % len(colors)], alpha=0.8)

    ax.set_xlabel("Training Step", fontsize=12)
    ax.set_ylabel("Average Loss", fontsize=12)
    ax.set_title("SGNS Training Curves", fontsize=14)
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    print(f"  Loss curve saved → {output_path}")


# ═══════════════════════════════════════════════════════════════════════════
# Neighbour Tables
# ═══════════════════════════════════════════════════════════════════════════

def print_and_save_neighbours(
    models: Dict[str, SGNSModel],
    probes: List[str],
    word2idx: Dict[str, int],
    idx2word: Dict[int, str],
    output_path: str,
    top_n: int = 10,
):
    """Print and save nearest neighbour tables for probe words."""
    lines = []

    for probe in probes:
        lines.append(f"\n{'─'*70}")
        lines.append(f"  Probe: {probe}")
        lines.append(f"{'─'*70}")

        for model_name, model in models.items():
            nn = model.nearest_neighbors(probe, word2idx, idx2word, top_n=top_n)
            if nn:
                nbrs = ", ".join(f"{w}({s:.3f})" for w, s in nn)
                lines.append(f"  [{model_name:12s}] {nbrs}")
            else:
                lines.append(f"  [{model_name:12s}] (not in vocab)")

    text = "\n".join(lines)
    print(text)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("SGNS NEAREST NEIGHBOURS\n")
        f.write("=" * 70 + "\n")
        f.write(f"Top-{top_n} neighbours by cosine similarity\n")
        f.write(text + "\n")

    print(f"\n  Neighbour table saved → {output_path}")


# ═══════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="SGNS from scratch — Task 1")
    parser.add_argument("--corpus-a", type=str, default="corpus_a.txt",
        help="DA (dialect) corpus path")
    parser.add_argument("--corpus-b", type=str, default="corpus_b.txt",
        help="DB (standard) corpus path")
    parser.add_argument("--dim", type=int, default=100,
        help="Embedding dimension (default: 100)")
    parser.add_argument("--epochs", type=int, default=5,
        help="Training epochs (default: 5)")
    parser.add_argument("--k", type=int, default=5,
        help="Negative samples per pair (default: 5)")
    parser.add_argument("--W", type=int, default=5,
        help="Max context window (default: 5)")
    parser.add_argument("--lr", type=float, default=5e-4,
        help="Learning rate for Adam (default: 5e-4)")
    parser.add_argument("--subsample-t", type=float, default=1e-4,
        help="Subsampling threshold (default: 1e-4; roadmap says 1e-5 but that's for large corpora)")
    parser.add_argument("--min-freq", type=int, default=3,
        help="Minimum word frequency for vocab (default: 3)")
    parser.add_argument("--seed", type=int, default=42,
        help="Random seed (default: 42)")
    parser.add_argument("--output-dir", type=str, default="outputs",
        help="Output directory (default: outputs)")
    args = parser.parse_args()

    # ── Reproducibility ────────────────────────────────────────────────
    SEED = args.seed
    random.seed(SEED)
    np.random.seed(SEED)

    os.makedirs(args.output_dir, exist_ok=True)

    # ── Load corpora ───────────────────────────────────────────────────
    print("=" * 70)
    print("SGNS — Skip-Gram with Negative Sampling")
    print("Assignment 1, Task 1")
    print("=" * 70)

    corpus_a = load_corpus(args.corpus_a)
    corpus_b = load_corpus(args.corpus_b)

    # ── Shared vocabulary ──────────────────────────────────────────────
    word2idx, idx2word, freq = build_vocab(
        corpus_a, corpus_b,
        min_freq=args.min_freq,
        max_vocab=30_000,
    )
    V = len(word2idx)

    # ── Encode ─────────────────────────────────────────────────────────
    enc_a = encode_corpus(corpus_a, word2idx)
    enc_b = encode_corpus(corpus_b, word2idx)
    enc_joint = enc_a + enc_b

    # ── Subsampling probabilities ──────────────────────────────────────
    keep_probs = build_subsample_probs(freq, word2idx, t=args.subsample_t)

    # ── Negative sampler ───────────────────────────────────────────────
    neg_sampler = AliasSampler(freq, word2idx)

    # ── Select probe words ─────────────────────────────────────────────
    # Find words that appear in BOTH corpora with reasonable frequency
    freq_a = Counter(w for sent in corpus_a for w in sent)
    freq_b = Counter(w for sent in corpus_b for w in sent)

    shared_words = sorted(
        [w for w in word2idx
         if w not in (PAD_TOKEN, UNK_TOKEN)
         and freq_a.get(w, 0) >= 2
         and freq_b.get(w, 0) >= 2],
        key=lambda w: -(freq_a.get(w, 0) + freq_b.get(w, 0)),
    )

    # Pick probes: mix of function words and content words
    probes = []
    # First: words that look like rural/content vocabulary (longer words)
    content_candidates = [w for w in shared_words if len(w) >= 4]
    probes.extend(content_candidates[:7])
    # Then: high-frequency shared words
    for w in shared_words:
        if w not in probes:
            probes.append(w)
        if len(probes) >= 10:
            break

    print(f"\n  Probe words ({len(probes)}): {probes}")

    # ══════════════════════════════════════════════════════════════════
    # Train 3 models: Joint (DA∪DB), DA-only, DB-only
    # ══════════════════════════════════════════════════════════════════
    curves = {}
    models = {}

    # ── Joint model ────────────────────────────────────────────────────
    print(f"\n{'='*70}")
    print("Training SGNS on JOINT corpus (DA ∪ DB)")
    print(f"  V={V}, d={args.dim}, k={args.k}, W={args.W}, η={args.lr}")
    print(f"{'='*70}")

    model_joint = SGNSModel(vocab_size=V, dim=args.dim, seed=SEED)
    curve_joint = train_sgns(
        model_joint, enc_joint, keep_probs, neg_sampler,
        epochs=args.epochs, k=args.k, W=args.W, lr=args.lr,
        seed=SEED, log_every=2000, label="Joint",
    )
    curves["Joint (DA∪DB)"] = curve_joint
    models["Joint"] = model_joint

    E_joint = model_joint.get_embeddings(normalize=False)
    np.save(os.path.join(args.output_dir, "sgns_embeddings_joint.npy"), E_joint)

    # ── DA-only model ──────────────────────────────────────────────────
    print(f"\n{'='*70}")
    print("Training SGNS on DA only (dialect)")
    print(f"{'='*70}")

    model_a = SGNSModel(vocab_size=V, dim=args.dim, seed=SEED)
    curve_a = train_sgns(
        model_a, enc_a, keep_probs, neg_sampler,
        epochs=max(args.epochs * 3, 15),  # more epochs for small corpus
        k=args.k, W=args.W, lr=args.lr,
        seed=SEED, log_every=1000, label="DA",
    )
    curves["DA (dialect)"] = curve_a
    models["DA"] = model_a

    E_a = model_a.get_embeddings(normalize=False)
    np.save(os.path.join(args.output_dir, "sgns_embeddings_a.npy"), E_a)

    # ── DB-only model ──────────────────────────────────────────────────
    print(f"\n{'='*70}")
    print("Training SGNS on DB only (standard)")
    print(f"{'='*70}")

    model_b = SGNSModel(vocab_size=V, dim=args.dim, seed=SEED)
    curve_b = train_sgns(
        model_b, enc_b, keep_probs, neg_sampler,
        epochs=args.epochs, k=args.k, W=args.W, lr=args.lr,
        seed=SEED, log_every=2000, label="DB",
    )
    curves["DB (standard)"] = curve_b
    models["DB"] = model_b

    E_b = model_b.get_embeddings(normalize=False)
    np.save(os.path.join(args.output_dir, "sgns_embeddings_b.npy"), E_b)

    # ══════════════════════════════════════════════════════════════════
    # Outputs
    # ══════════════════════════════════════════════════════════════════

    # ── Loss curves ────────────────────────────────────────────────────
    plot_loss_curves(curves, os.path.join(args.output_dir, "sgns_loss_curve.png"))

    # ── Neighbour tables ───────────────────────────────────────────────
    print(f"\n{'='*70}")
    print("NEAREST NEIGHBOURS FOR PROBE WORDS")
    print(f"{'='*70}")

    print_and_save_neighbours(
        models, probes, word2idx, idx2word,
        os.path.join(args.output_dir, "sgns_neighbours.txt"),
        top_n=10,
    )

    # ── Save vocab mapping ─────────────────────────────────────────────
    import json
    with open(os.path.join(args.output_dir, "sgns_vocab.json"), "w") as f:
        json.dump({
            "word2idx": word2idx,
            "probes": probes,
            "hyperparams": {
                "dim": args.dim,
                "k": args.k,
                "W": args.W,
                "lr": args.lr,
                "min_freq": args.min_freq,
                "epochs": args.epochs,
                "seed": SEED,
            },
            "corpus_stats": {
                "DA_sentences": len(corpus_a),
                "DB_sentences": len(corpus_b),
                "vocab_size": V,
            },
        }, f, indent=2, ensure_ascii=False)

    # ── Summary ────────────────────────────────────────────────────────
    print(f"\n{'='*70}")
    print("TRAINING COMPLETE")
    print(f"{'='*70}")
    print(f"  Embeddings:  {args.output_dir}/sgns_embeddings_{{joint,a,b}}.npy")
    print(f"  Loss curve:  {args.output_dir}/sgns_loss_curve.png")
    print(f"  Neighbours:  {args.output_dir}/sgns_neighbours.txt")
    print(f"  Vocab/meta:  {args.output_dir}/sgns_vocab.json")


if __name__ == "__main__":
    main()
