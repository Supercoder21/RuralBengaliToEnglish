"""
data_utils.py
-------------
Corpus loading, tokenization, shared vocabulary construction,
subsampling of frequent words, and alias sampler for negative sampling.

Adapted for ROMANISED BENGALI (ITRANS lowercase output from asr_pipeline.py).

Corpus design
-------------
DA = corpus_a.txt : rural Bengali dialect (Whisper ASR → ITRANS)
DB = corpus_b.txt : standard Bengali      (OpenSLR-53 → ITRANS)

Both files are one sentence per line, lowercase ASCII (ITRANS romanisation).

Usage:
    from data_utils import load_corpus, build_vocab, AliasSampler
    corpus_a = load_corpus("data/corpus_a.txt")
    corpus_b = load_corpus("data/corpus_b.txt")
    word2idx, idx2word, freq = build_vocab(corpus_a, corpus_b, min_freq=5)

Authors: Avnish (embeddings & metrics lead)
"""

import re
import math
import random
import numpy as np
from collections import Counter
from typing import List, Tuple, Dict, Optional


# ─────────────────────────────────────────────
# 1. Tokenisation (for romanised Bengali)
# ─────────────────────────────────────────────

def tokenize(text: str) -> List[str]:
    """
    Tokenise romanised Bengali (ITRANS lowercase).

    ITRANS output is already lowercase ASCII. We split on whitespace
    and strip any residual punctuation. Bengali doesn't use hyphens
    or apostrophes the way English does, so we keep it simple.

    Examples:
        "ami vajare yai"  → ["ami", "vajare", "yai"]
        "mati chasha kari" → ["mati", "chasha", "kari"]
    """
    text = text.strip().lower()
    # Keep only alphabetic sequences (ITRANS is pure a-z after pipeline)
    tokens = re.findall(r"[a-z]+", text)
    return tokens


def load_corpus(
    path: str,
    max_sentences: Optional[int] = None,
) -> List[List[str]]:
    """
    Load a transliterated corpus file. One line = one sentence.
    Returns list of tokenized sentences.

    Parameters
    ----------
    path : path to corpus file (corpus_a.txt or corpus_b.txt)
    max_sentences : optional cap on number of sentences to load

    Returns
    -------
    List[List[str]] : tokenized sentences
    """
    sentences = []
    with open(path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if max_sentences and i >= max_sentences:
                break
            line = line.strip()
            if line:
                tokens = tokenize(line)
                if len(tokens) >= 2:  # skip degenerate sentences
                    sentences.append(tokens)

    print(f"[Corpus] Loaded {len(sentences):,} sentences from {path}")
    return sentences


# ─────────────────────────────────────────────
# 2. Vocabulary
# ─────────────────────────────────────────────

PAD_TOKEN = "<PAD>"   # index 0 (reserved)
UNK_TOKEN = "<UNK>"   # index 1

def build_vocab(
    corpus_a: List[List[str]],
    corpus_b: List[List[str]],
    min_freq: int = 5,
    max_vocab: int = 30_000,
) -> Tuple[Dict[str, int], Dict[int, str], Counter]:
    """
    Build a *shared* vocabulary from DA ∪ DB.

    Per roadmap spec:
        - min_freq ≥ 5
        - |V| ≤ 30,000
        - OOV tokens → <UNK>

    Returns
    -------
    word2idx : str -> int
    idx2word : int -> str
    freq     : Counter mapping word -> raw count (in full joint corpus)
    """
    all_tokens = [t for sent in corpus_a + corpus_b for t in sent]
    freq = Counter(all_tokens)

    # Keep only frequent words, sorted by frequency desc (stable tiebreak)
    vocab_words = sorted(
        [w for w, c in freq.items() if c >= min_freq],
        key=lambda w: (-freq[w], w),
    )[:max_vocab]

    word2idx: Dict[str, int] = {PAD_TOKEN: 0, UNK_TOKEN: 1}
    for w in vocab_words:
        word2idx[w] = len(word2idx)
    idx2word: Dict[int, str] = {v: k for k, v in word2idx.items()}

    print(
        f"[Vocab] Joint vocab size: {len(word2idx):,}  "
        f"(after min_freq={min_freq}, max_vocab={max_vocab})"
    )
    print(
        f"  Total tokens: {len(all_tokens):,}  |  "
        f"Unique types: {len(freq):,}  |  "
        f"Types with freq≥{min_freq}: {len(vocab_words):,}"
    )
    return word2idx, idx2word, freq


def encode_corpus(
    corpus: List[List[str]],
    word2idx: Dict[str, int],
) -> List[List[int]]:
    """Replace every token with its index; OOV → UNK index."""
    unk = word2idx[UNK_TOKEN]
    return [[word2idx.get(t, unk) for t in sent] for sent in corpus]


# ─────────────────────────────────────────────
# 3. Mikolov-style subsampling
# ─────────────────────────────────────────────

def build_subsample_probs(
    freq: Counter,
    word2idx: Dict[str, int],
    t: float = 1e-5,
) -> np.ndarray:
    """
    P(keep word w) = min(1, sqrt(t / f(w)))
    where f(w) = count(w) / total_tokens.

    Per roadmap: t = 10^-5, P(discard w) = 1 - sqrt(t/f(w))

    Returns array of shape (|V|,) with keep probabilities.
    """
    total = sum(freq[w] for w in freq)
    probs = np.ones(len(word2idx), dtype=np.float32)
    for word, idx in word2idx.items():
        if word in (PAD_TOKEN, UNK_TOKEN):
            probs[idx] = 0.0  # always discard special tokens
        else:
            fw = freq.get(word, 0) / total
            probs[idx] = min(1.0, math.sqrt(t / fw)) if fw > 0 else 0.0
    return probs


def subsample_corpus(
    encoded_corpus: List[List[int]],
    keep_probs: np.ndarray,
    rng: np.random.Generator,
) -> List[List[int]]:
    """Apply Mikolov subsampling: drop each token with P(discard) = 1-keep_prob."""
    out = []
    for sent in encoded_corpus:
        kept = [
            idx for idx in sent
            if rng.random() < keep_probs[idx]
        ]
        if len(kept) >= 2:   # skip degenerate sentences
            out.append(kept)
    return out


# ─────────────────────────────────────────────
# 4. Alias sampler for negative sampling
# ─────────────────────────────────────────────

class AliasSampler:
    """
    Vose's O(1) alias method for sampling from an arbitrary discrete distribution.
    Used to sample negatives from P_neg(w) ∝ freq(w)^(3/4).

    Per roadmap: negative sampling distribution P_neg(x) ∝ f(x)^{3/4}
    """

    def __init__(self, freq: Counter, word2idx: Dict[str, int]):
        # Build the 3/4-power distribution over *vocab indices*
        n = len(word2idx)
        raw = np.zeros(n, dtype=np.float64)
        for word, idx in word2idx.items():
            if word not in (PAD_TOKEN, UNK_TOKEN):
                raw[idx] = freq.get(word, 0) ** 0.75
        raw /= raw.sum()

        # Vose's algorithm
        prob = raw * n        # scale so mean = 1
        alias = np.zeros(n, dtype=np.int64)
        small, large = [], []
        for i, p in enumerate(prob):
            (small if p < 1.0 else large).append(i)

        while small and large:
            s = small.pop()
            l = large.pop()
            alias[s] = l
            prob[l] -= (1.0 - prob[s])
            (small if prob[l] < 1.0 else large).append(l)

        self._prob = prob
        self._alias = alias
        self._n = n

    def sample(self, k: int, rng: np.random.Generator) -> np.ndarray:
        """Draw k samples in O(k)."""
        i = rng.integers(0, self._n, size=k)
        flip = rng.random(size=k) < self._prob[i]
        return np.where(flip, i, self._alias[i])


# ─────────────────────────────────────────────
# 5. Pair generator (positive (target, context) pairs)
# ─────────────────────────────────────────────

def iter_skipgram_pairs(
    encoded_corpus: List[List[int]],
    W: int = 5,
    rng: Optional[np.random.Generator] = None,
):
    """
    Yield (target_idx, context_idx) pairs with a random window
    uniformly drawn from {1, ..., W} for each target.

    Per roadmap: W = 5 (random context window size ∈ {1,...,W})
    """
    if rng is None:
        rng = np.random.default_rng()
    for sent in encoded_corpus:
        for i, target in enumerate(sent):
            window = int(rng.integers(1, W + 1))
            start = max(0, i - window)
            end = min(len(sent), i + window + 1)
            for j in range(start, end):
                if j != i:
                    yield target, sent[j]


# ─────────────────────────────────────────────
# 6. Utility: shared probe words for Bengali
# ─────────────────────────────────────────────

# These are ITRANS romanisations of Bengali words relevant to rural life.
# The actual probes should be selected AFTER building the vocabulary,
# confirming they appear in both DA and DB with sufficient frequency.
#
# Candidates (update after inspecting your actual vocab):
PROBE_CANDIDATES_RURAL = [
    "vajara",   # বাজার  — market
    "mati",     # মাটি   — earth/soil
    "nauka",    # নৌকা   — boat
    "dhana",    # ধান    — paddy/rice
    "goru",     # গোরু   — cow
    "hata",     # হাট    — village market
    "nadi",     # নদী    — river
    "macha",    # মাছ    — fish
    "chasha",   # চাষ    — farming/cultivation
    "grama",    # গ্রাম   — village
    "pani",     # পানি   — water
    "ghara",    # ঘর    — house
    "rashta",   # রাস্তা  — road
    "ksheta",   # ক্ষেত  — field (agricultural)
    "vriShTi",  # বৃষ্টি  — rain
]


def select_probe_words(
    word2idx: Dict[str, int],
    freq: Counter,
    candidates: Optional[List[str]] = None,
    n_probes: int = 10,
    min_count: int = 20,
) -> List[str]:
    """
    Select probe words that exist in vocabulary with sufficient frequency.
    Falls back to top-frequency non-stopword tokens if candidates don't work.

    Per roadmap: 10 probe words relevant to rural life
    """
    if candidates is None:
        candidates = PROBE_CANDIDATES_RURAL

    # Try candidates first
    probes = [w for w in candidates if w in word2idx and freq.get(w, 0) >= min_count]

    if len(probes) >= n_probes:
        return probes[:n_probes]

    # Fall back: pick frequent content words (skip very short function words)
    print(f"  [Probes] Only {len(probes)} candidates found in vocab; "
          f"selecting from frequent types")
    sorted_words = sorted(
        [(w, c) for w, c in freq.items()
         if w in word2idx and len(w) >= 4 and c >= min_count],
        key=lambda x: -x[1],
    )
    for w, c in sorted_words:
        if w not in probes:
            probes.append(w)
            if len(probes) >= n_probes:
                break

    print(f"  [Probes] Selected {len(probes)} probe words: {probes}")
    return probes
