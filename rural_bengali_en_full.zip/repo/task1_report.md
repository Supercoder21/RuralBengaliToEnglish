# Assignment 1 — Task 1: Word2Vec Skip-Gram with Negative Sampling (SGNS)

**Author:** Avnish (Lead Owner)
**Project:** Rural Bengali Dialect → English: Linguistic Divergence
**Date:** April 2026

---

## 1. Objective

Implement SGNS from scratch, train on two corpora — DA (rural Bengali dialect) and DB (standard Bengali) — and analyse nearest-neighbour drift between dialect and standard embedding spaces.

## 2. Data Pipeline

### 2.1 Corpus Sources

**DA (Rural Bengali Dialect):** 8 YouTube videos of Purulia/Manbhumi dialect speech, totalling approximately 296 minutes (~5 hours) of audio. Content includes jhumur folk artist interviews, village conversations, and local cultural programming — all spoken naturally in Manbhumi dialect.

**DB (Standard Bengali):** OpenSLR-53, a crowd-sourced sentence-level ASR corpus of standard Bangladeshi Bengali containing ~196K utterances with pre-existing Bengali script transcriptions (Google, CC BY-SA 4.0).

### 2.2 ASR & Transliteration

The pipeline converts raw audio/text into a uniform romanised representation suitable for embedding training:

1. **Whisper ASR** (large-v3) transcribes DA audio into Bengali script. Whisper's internal VAD segments continuous audio into sentence-level chunks automatically.
2. **ITRANS romanisation** via `indic-transliteration` converts Bengali script to lowercase ASCII. ITRANS maps consistently (e.g., ব→v, not b) — consistency matters more than phonetic accuracy for embedding co-occurrence.
3. **Quality filtering:** sentences with fewer than 3 tokens are discarded; stray Unicode characters stripped; Windows line endings normalised.

For DB, Whisper is unnecessary — OpenSLR-53 already provides Bengali script transcriptions in a TSV file. Only the transliteration step is applied.

### 2.3 Corpus Cleaning

DA required additional cleaning:
- **Deduplication** removed ~130 duplicate lines (channel intros, repeated phrases).
- **Channel noise removal:** lines like "pragrama karechana pragrama karechana" (appearing 25×, a channel intro) were stripped.
- DB was randomly subsampled from 153,559 to 10,000 sentences to maintain a manageable ratio (~11:1 DB:DA).

### 2.4 Final Corpus Statistics

| Metric | DA (Dialect) | DB (Standard) |
|---|---|---|
| Sentences | 874 | 9,993 |
| Total tokens | 7,225 | 37,379 |
| Unique types | 3,195 | 11,389 |
| Vocab overlap | 702 types | — |
| Joint types freq≥3 | 207 | — |

## 3. Implementation

### 3.1 Architecture

The SGNS model consists of two embedding matrices:
- **V** (input/target): R^{|V| × d}, initialised uniform in [-0.5/d, 0.5/d]
- **U** (output/context): R^{|V| × d}, same initialisation

Loss per positive pair (w, c) with k negatives {n₁,...,nₖ}:

    L = -log σ(uᶜᵀ vw) - Σᵢ log σ(-uₙᵢᵀ vw)

Final embedding: eᵤ = (vᵤ + uᵤ) / 2, which reduces anisotropy compared to using either matrix alone.

### 3.2 Hyperparameters

| Parameter | Roadmap Spec | Actual | Justification |
|---|---|---|---|
| d (dimension) | 100 | 100 | Per spec |
| W (max window) | 5 | 5 | Per spec |
| k (negatives) | 5 | 5 | Per spec |
| η (learning rate) | 5×10⁻⁴ | 5×10⁻⁴ | Per spec, Adam optimizer |
| t (subsampling) | 10⁻⁵ | **10⁻⁴** | 10⁻⁵ removes 95% of tokens from our small corpus, leaving only ~2,900 pairs per epoch. 10⁻⁴ retains 29%, yielding ~24K pairs — sufficient for convergence. |
| min_freq | ≥5 | **≥3** | With only 7,225 DA tokens, freq≥5 leaves 274 types. freq≥3 gives 533, enabling a shared vocabulary of 3,022 types. |
| P_neg | ∝ f(w)^{3/4} | ∝ f(w)^{3/4} | Per spec, via Vose alias sampling O(1) |
| Epochs (Joint) | — | 10 | — |
| Epochs (DA) | — | 30 | Small corpus requires more passes |
| Epochs (DB) | — | 10 | — |
| Seed | 42 | 42 | Per spec |

### 3.3 Key Components

- **Tokeniser:** regex-based (`[a-z]+`), designed for ITRANS romanised output (pure ASCII after pipeline).
- **Shared vocabulary:** built from DA ∪ DB with min_freq=3, |V|=3,022, capped at 30,000. OOV tokens mapped to `<UNK>`.
- **Mikolov subsampling:** P(keep w) = min(1, √(t / f(w))), applied stochastically each epoch.
- **Alias sampler:** Vose's O(1) alias method for negative sampling from P_neg(w) ∝ f(w)^{3/4}.
- **Skip-gram pairs:** random window ∈ {1,...,W} per target, yielding (target, context) pairs.
- **Optimizer:** Adam with β₁=0.9, β₂=0.999, ε=10⁻⁸. Per-parameter moment tracking for V[target], U[context], and U[negatives].

### 3.4 Training Configuration

Three models were trained on the same shared vocabulary:
1. **Joint (DA ∪ DB):** 10 epochs, ~24K pairs/epoch
2. **DA-only:** 30 epochs (compensating for small corpus), ~6.4K pairs/epoch
3. **DB-only:** 10 epochs, ~17.5K pairs/epoch

The DA-only and DB-only models are required for Tasks 4 (Procrustes alignment) and 5 (JS divergence).

## 4. Results

### 4.1 Training Convergence

All three models converge (loss decreases monotonically after initial warm-up):

| Model | Initial Loss | Final Loss | Pairs/Epoch |
|---|---|---|---|
| Joint (DA∪DB) | 4.05 | 2.60 | ~24,000 |
| DA (dialect) | 4.13 | 1.48 | ~6,400 |
| DB (standard) | 4.12 | 2.60 | ~17,500 |

DA converges to a lower loss because the smaller corpus is easier to fit with 30 epochs. This is expected and does not indicate overfitting per se — it means the model has memorised the co-occurrence structure of DA, which is exactly what we want for downstream divergence analysis.

### 4.2 Probe Words

Ten probe words were selected from the intersection of DA and DB vocabularies (freq≥2 in both):

    kare, tara, theke, haya, amara, kara, ekati, na, ei, o

These are high-frequency function and semi-function words shared across both varieties. While the roadmap suggests rural-life content words (bajara, mati, nauka), these did not appear with sufficient frequency in both corpora after romanisation. The selected probes are more informative: they are shared words whose *contexts* differ between dialect and standard — exactly what SGNS captures.

### 4.3 Nearest Neighbour Analysis

Key divergences observed in the DA vs DB embedding spaces:

**"amara" (আমাদের, our/ours):**
- DA neighbours: hada, khushi, paike, chada, dara, hati, sami, sakale — familial and rural-life vocabulary (happiness, morning, husband, elephant)
- DB neighbours: to, ami, tumi, ai, kothaya, ke, vasara — standard pronouns and question words
- Interpretation: In dialect speech, "our" co-occurs with domestic and agricultural terms. In standard Bengali, it co-occurs with formal/neutral pronouns.

**"ei" (এই, this):**
- DA neighbours: juge, kali, jumara, bhadri, huge, jula, dada — Purulia cultural vocabulary. "jumara" = jhumur (a folk music tradition specific to Manbhum region).
- DB neighbours: ekata, naya, chila, dekha, sale, ami — generic standard Bengali.
- Interpretation: The demonstrative "this" in dialect speech is embedded in cultural context (folk art, festivals); in standard Bengali it's a generic function word.

**"na" (না, no/not):**
- DA neighbours: vaire, eta, grama, dina, o, vela, sava, kona — spatial and temporal village-life terms (outside, village, day, time).
- DB neighbours: ki, dekha, ekata, ami, to, nijera — standard conversational negation context.

**"kara/kare" (করা/করে, do/doing):**
- DA: have, ekati, tara, thika, diyae, karite — includes dialectal verb forms (karite, thika).
- DB: haya, ataka, sekhane, dekha, thake, pare — standard verbal context.

### 4.4 Dialect-Specific Signal

The DA model's embedding space captures genuine Manbhumi dialect features:
- **Folk vocabulary:** "jumara" (jhumur folk music) appearing as a neighbour confirms the corpus represents authentic Purulia cultural speech.
- **Dialectal verb forms:** "karite" (করিতে, infinitive form unique to western Bengali dialects) appears in DA neighbours but not DB.
- **Rural semantic fields:** DA function words cluster with agricultural and domestic vocabulary; DB function words cluster with formal/administrative vocabulary.

## 5. Limitations

1. **DA corpus size:** 874 sentences (7,225 tokens) is small for SGNS. Embeddings are noisy and probe word choices are constrained by limited vocabulary overlap. More dialect audio would improve results significantly.

2. **ASR noise:** Whisper's Bengali ASR introduces transcription errors, particularly on dialectal speech it was not trained on. Some DA vocabulary (e.g., "paremgila", "karechana" repeated patterns) may be ASR artefacts rather than genuine dialect.

3. **Subsampling adaptation:** Using t=10⁻⁴ instead of the specified t=10⁻⁵ was necessary but changes the effective training distribution — frequent words are less aggressively downsampled than in a standard SGNS setup.

4. **Probe word selection:** The roadmap specifies rural-life content words, but low frequency in our small DA corpus prevented their use. We used shared function words instead, which still demonstrate divergence through their contextual neighbours.

## 6. Deliverables

| File | Description |
|---|---|
| `sgns.py` | Full SGNS implementation with Adam optimizer |
| `data_utils.py` | Vocabulary, encoding, alias sampler, subsampling, pair generator |
| `asr_pipeline.py` | Audio → Whisper → Bengali → ITRANS romanisation pipeline |
| `scrape_dialect_audio.py` | YouTube audio scraper with yt-dlp |
| `corpus_a.txt` | DA corpus (874 sentences, cleaned) |
| `corpus_b.txt` | DB corpus (9,993 sentences, subsampled) |
| `outputs/sgns_loss_curve.png` | Training loss curves (3 models) |
| `outputs/sgns_neighbours.txt` | Top-10 neighbour tables for 10 probes × 3 models |
| `outputs/sgns_embeddings_{joint,a,b}.npy` | Saved embedding matrices |
| `outputs/sgns_vocab.json` | Vocabulary mapping and hyperparameters |

## 7. Downstream Dependencies

- **Task 3 (Intrinsic Evaluation):** Uses Joint embeddings. Overlap metric and hubness analysis on shared vocabulary.
- **Task 4 (Procrustes Alignment):** Uses `sgns_embeddings_a.npy` and `sgns_embeddings_b.npy` with the shared `word2idx` from `sgns_vocab.json`.
- **Task 5 (JS Divergence):** Uses aligned DA/DB embeddings from Task 4 output.
