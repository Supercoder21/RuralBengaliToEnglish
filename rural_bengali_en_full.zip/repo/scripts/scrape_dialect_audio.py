#!/usr/bin/env python3
"""
scrape_dialect_audio.py
=======================
Download long-form Bengali dialect audio from YouTube using yt-dlp.

Two modes:
  1. URL list mode:  provide a file with one YouTube URL per line
  2. Search mode:    provide search queries (yt-dlp searches YouTube)

Outputs audio-only files (.wav 16kHz mono) ready for Whisper.

Setup:
    pip install yt-dlp
    # yt-dlp also needs ffmpeg on PATH
    # Ubuntu:  sudo apt install ffmpeg
    # macOS:   brew install ffmpeg

Usage:
    # From a URL list (recommended — curate URLs in your browser first)
    python scrape_dialect_audio.py --url-file urls_dialect.txt --output-dir ../data/dialect_audio

    # From search queries
    python scrape_dialect_audio.py --search-file queries.txt --output-dir ../data/dialect_audio --max-per-query 5

    # Single URL
    python scrape_dialect_audio.py --url "https://youtube.com/watch?v=..." --output-dir ../data/dialect_audio

Authors: Avnish
"""

import os
import sys
import json
import argparse
import subprocess
from pathlib import Path
from typing import List, Optional


# ═══════════════════════════════════════════════════════════════════════════
# Core download function
# ═══════════════════════════════════════════════════════════════════════════

def download_audio(
    url: str,
    output_dir: str,
    min_duration: int = 120,     # skip clips shorter than 2 min
    max_duration: int = 7200,    # skip clips longer than 2 hours
    sample_rate: int = 16000,    # Whisper expects 16kHz
) -> Optional[str]:
    """
    Download audio from a YouTube URL as 16kHz mono WAV.

    Returns path to downloaded file, or None on failure.
    """
    os.makedirs(output_dir, exist_ok=True)

    # Output template: use video ID as filename to avoid duplicates
    outtmpl = os.path.join(output_dir, "%(id)s.%(ext)s")

    cmd = [
        "yt-dlp",
        "--extract-audio",
        "--audio-format", "wav",
        "--audio-quality", "0",
        # Post-process to 16kHz mono (what Whisper wants)
        "--postprocessor-args", f"ffmpeg:-ar {sample_rate} -ac 1",
        # Duration filter
        "--match-filter", f"duration >= {min_duration} & duration <= {max_duration}",
        # Output naming
        "--output", outtmpl,
        # Don't re-download
        "--no-overwrites",
        # Write metadata for provenance
        "--write-info-json",
        # No video
        "--no-video",
        # Quiet-ish
        "--progress",
        "--no-warnings",
        url,
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if result.returncode == 0:
            # Find the output file
            for f in Path(output_dir).glob("*.wav"):
                if f.stat().st_size > 0:
                    return str(f)
            return None
        else:
            print(f"  [FAIL] {url}")
            if "duration" in result.stderr.lower():
                print(f"    Skipped: duration outside [{min_duration}s, {max_duration}s]")
            else:
                print(f"    stderr: {result.stderr[:200]}")
            return None
    except subprocess.TimeoutExpired:
        print(f"  [TIMEOUT] {url}")
        return None
    except FileNotFoundError:
        print("ERROR: yt-dlp not found. Install with: pip install yt-dlp")
        sys.exit(1)


def search_and_download(
    query: str,
    output_dir: str,
    max_results: int = 5,
    min_duration: int = 120,
    max_duration: int = 7200,
) -> List[str]:
    """
    Search YouTube for a query and download matching audio.

    Returns list of downloaded file paths.
    """
    # Use yt-dlp's built-in YouTube search
    search_url = f"ytsearch{max_results}:{query}"

    cmd = [
        "yt-dlp",
        "--extract-audio",
        "--audio-format", "wav",
        "--audio-quality", "0",
        "--postprocessor-args", f"ffmpeg:-ar 16000 -ac 1",
        "--match-filter", f"duration >= {min_duration} & duration <= {max_duration}",
        "--output", os.path.join(output_dir, "%(id)s.%(ext)s"),
        "--no-overwrites",
        "--write-info-json",
        "--no-video",
        "--progress",
        search_url,
    ]

    os.makedirs(output_dir, exist_ok=True)

    try:
        before = set(Path(output_dir).glob("*.wav"))
        subprocess.run(cmd, timeout=1200)
        after = set(Path(output_dir).glob("*.wav"))
        new_files = after - before
        return [str(f) for f in new_files]
    except subprocess.TimeoutExpired:
        print(f"  [TIMEOUT] Search: {query}")
        return []
    except FileNotFoundError:
        print("ERROR: yt-dlp not found. Install with: pip install yt-dlp")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════
# Post-download inventory
# ═══════════════════════════════════════════════════════════════════════════

def inventory(output_dir: str):
    """Print summary of downloaded audio files."""
    wav_files = sorted(Path(output_dir).glob("*.wav"))
    if not wav_files:
        print("\n  No audio files found.")
        return

    total_bytes = 0
    print(f"\n  {'File':<20s} {'Size (MB)':>10s}  {'Duration (est.)':>15s}")
    print(f"  {'─'*20} {'─'*10}  {'─'*15}")

    for f in wav_files:
        size = f.stat().st_size
        total_bytes += size
        # Rough duration estimate: 16kHz × 16-bit × mono = 32000 bytes/sec
        est_seconds = size / 32000
        est_min = est_seconds / 60
        print(f"  {f.name:<20s} {size/1e6:>10.1f}  {est_min:>12.1f} min")

    total_min = (total_bytes / 32000) / 60
    print(f"\n  Total: {len(wav_files)} files, {total_bytes/1e9:.2f} GB, ~{total_min:.0f} min")
    print(f"  At ~5 sentences/min from Whisper, expect ~{total_min*5:.0f} sentences")


# ═══════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════

# ── RECOMMENDED SEARCH QUERIES ──────────────────────────────────────────
# Copy these into a file (one per line) and use --search-file,
# or search YouTube manually and save URLs to a file for --url-file.
#
# The goal: SPOKEN rural Bengali dialect, 10+ minutes each.
# Best content types: interviews, folk commentary, local news, village life docs.
#
# ┌─────────────────────────────────────────────────────────────────────┐
# │  MANBHUMI / PURULIA DIALECT (Western Bengali — strongest shift)   │
# ├─────────────────────────────────────────────────────────────────────┤
# │  পুরুলিয়া গ্রামের কথা interview                                      │
# │  মানভূমী ভাষা কথোপকথন                                              │
# │  purulia village life documentary bengali                         │
# │  পুরুলিয়া জেলার খবর                                                │
# │  ছৌ নাচ পুরুলিয়া interview                                         │
# │  টুসু পরব পুরুলিয়া গান আলোচনা                                       │
# │  bankura village bengali interview                                │
# │  purulia folk singer interview bangla                             │
# │  মেদিনীপুর গ্রামের মানুষ কথা বলছে                                    │
# │  jharkhand bengali speaking village                               │
# ├─────────────────────────────────────────────────────────────────────┤
# │  ALTERNATIVE DIALECTS (also high divergence)                      │
# ├─────────────────────────────────────────────────────────────────────┤
# │  sylheti bangla interview কথোপকথন                                 │
# │  chittagong dialect conversation long                             │
# │  noakhali bangla কথা interview                                    │
# │  rangpur dialect interview                                        │
# │  barishal ancholik bhasha কথোপকথন                                 │
# └─────────────────────────────────────────────────────────────────────┘
#
# TIPS FOR MANUAL CURATION (best approach):
#   1. Search YouTube with queries above
#   2. Filter by duration > 20 minutes
#   3. Prefer: interviews, talk shows, local news, village documentaries
#   4. Avoid: music videos (lyrics ≠ speech), Kolkata studio content
#   5. Save URLs to a text file, one per line
#   6. Run: python scrape_dialect_audio.py --url-file my_urls.txt

EXAMPLE_QUERIES = [
    "পুরুলিয়া গ্রামের কথা interview",
    "মানভূমী ভাষা কথোপকথন",
    "purulia village life documentary bengali",
    "পুরুলিয়া জেলার খবর",
    "ছৌ নাচ পুরুলিয়া interview",
    "bankura village bengali interview",
    "purulia folk singer interview bangla",
    "মেদিনীপুর গ্রামের মানুষ কথা বলছে",
]


def main():
    parser = argparse.ArgumentParser(
        description="Download long-form Bengali dialect audio from YouTube",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # From curated URL list (best approach)
  python scrape_dialect_audio.py --url-file urls.txt --output-dir ../data/dialect_audio

  # Search YouTube directly
  python scrape_dialect_audio.py --search-file queries.txt --output-dir ../data/dialect_audio

  # Single video
  python scrape_dialect_audio.py --url "https://youtu.be/..." --output-dir ../data/dialect_audio

  # Use built-in example queries
  python scrape_dialect_audio.py --example-queries --output-dir ../data/dialect_audio
        """,
    )

    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--url', type=str, help='Single YouTube URL')
    source.add_argument('--url-file', type=str, help='File with one URL per line')
    source.add_argument('--search-file', type=str, help='File with one search query per line')
    source.add_argument('--example-queries', action='store_true',
        help='Use built-in Purulia/Manbhumi search queries')

    parser.add_argument('--output-dir', type=str, default='../data/dialect_audio',
        help='Output directory (default: ../data/dialect_audio)')
    parser.add_argument('--min-duration', type=int, default=120,
        help='Min video duration in seconds (default: 120 = 2 min)')
    parser.add_argument('--max-duration', type=int, default=7200,
        help='Max video duration in seconds (default: 7200 = 2 hr)')
    parser.add_argument('--max-per-query', type=int, default=5,
        help='Max results per search query (default: 5)')

    args = parser.parse_args()

    print("=" * 60)
    print("Bengali Dialect Audio Scraper")
    print("=" * 60)

    downloaded = []

    if args.url:
        print(f"\n  Downloading: {args.url}")
        path = download_audio(args.url, args.output_dir,
                              min_duration=args.min_duration,
                              max_duration=args.max_duration)
        if path:
            downloaded.append(path)

    elif args.url_file:
        with open(args.url_file) as f:
            urls = [line.strip() for line in f if line.strip() and not line.startswith('#')]
        print(f"\n  Processing {len(urls)} URLs from {args.url_file}")
        for i, url in enumerate(urls, 1):
            print(f"\n  [{i}/{len(urls)}] {url}")
            path = download_audio(url, args.output_dir,
                                  min_duration=args.min_duration,
                                  max_duration=args.max_duration)
            if path:
                downloaded.append(path)

    elif args.search_file or args.example_queries:
        if args.example_queries:
            queries = EXAMPLE_QUERIES
            print(f"\n  Using {len(queries)} built-in Purulia/Manbhumi queries")
        else:
            with open(args.search_file) as f:
                queries = [line.strip() for line in f if line.strip() and not line.startswith('#')]
            print(f"\n  Processing {len(queries)} search queries")

        for i, query in enumerate(queries, 1):
            print(f"\n  [{i}/{len(queries)}] Searching: {query}")
            paths = search_and_download(query, args.output_dir,
                                        max_results=args.max_per_query,
                                        min_duration=args.min_duration,
                                        max_duration=args.max_duration)
            downloaded.extend(paths)

    # Summary
    print(f"\n{'='*60}")
    print(f"DOWNLOAD COMPLETE: {len(downloaded)} files")
    print(f"{'='*60}")
    inventory(args.output_dir)

    print(f"\n  Next step:")
    print(f"    python asr_pipeline.py --da-audio-dir {args.output_dir} --output-dir ../data --skip-db")


if __name__ == "__main__":
    main()
