#!/usr/bin/env python3
"""
asr_pipeline.py
===============
Audio → Transliterated Roman Text pipeline for the Linguistic Divergence project.

Pipeline:
    1. Download OpenSLR-53 (standard Bengali, DB) — already transcribed
    2. Whisper ASR on rural dialect audio (DA)
    3. Bengali script → lowercased ITRANS romanisation (both corpora)
    4. Output: data/corpus_a.txt, data/corpus_b.txt  (one sentence per line)

Usage:
    # Full pipeline — DB from OpenSLR, DA from your audio folder
    python asr_pipeline.py --da-audio-dir /path/to/dialect/audio \
                           --output-dir ../data \
                           --whisper-model large-v3 \
                           --openslr-zip-count 2

    # DA only (if you already have DB)
    python asr_pipeline.py --da-audio-dir /path/to/dialect/audio \
                           --output-dir ../data \
                           --skip-db

    # DB only (if you already have DA)
    python asr_pipeline.py --output-dir ../data --skip-da

Requirements:
    pip install openai-whisper indic-transliteration tqdm requests

Notes:
    - OpenSLR-53 has ~196K utterances across 10 zip files (~900MB each).
      --openslr-zip-count controls how many to download (2 ≈ 40K sentences).
    - Whisper large-v3 is recommended for Bengali; medium works too.
    - DA audio: place .wav/.mp3/.flac files in a directory. Whisper handles
      sentence segmentation automatically via its VAD.
    - The transliterator uses ITRANS (lowercased, ASCII-only). This maps
      ব→v (not b), which is fine — SGNS only needs consistency.

Authors: Avnish (embeddings & metrics lead)
"""

import os
import re
import sys
import glob
import json
import shutil
import hashlib
import argparse
import zipfile
import unicodedata
from pathlib import Path
from typing import List, Optional, Tuple

# ═══════════════════════════════════════════════════════════════════════════
# Lazy imports (so --help works without all deps installed)
# ═══════════════════════════════════════════════════════════════════════════

def _import_whisper():
    try:
        import whisper
        return whisper
    except ImportError:
        print("ERROR: openai-whisper not installed. Run: pip install openai-whisper")
        sys.exit(1)

def _import_transliteration():
    try:
        from indic_transliteration import sanscript
        from indic_transliteration.sanscript import transliterate
        return sanscript, transliterate
    except ImportError:
        print("ERROR: indic-transliteration not installed. Run: pip install indic-transliteration")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════
# Part 1: Transliteration — Bengali script → lowercased ITRANS
# ═══════════════════════════════════════════════════════════════════════════

# Characters that leak through ITRANS transliteration
_STRAY_UNICODE = re.compile(r'[^\x00-\x7F]')  # anything non-ASCII
_MULTI_SPACE   = re.compile(r'\s+')

def transliterate_bengali(text: str) -> str:
    """
    Convert Bengali script text to lowercased ITRANS romanisation.

    Pipeline:
        1. Normalise Unicode (NFC — compose diacritics)
        2. ITRANS transliterate via indic_transliteration
        3. Strip any residual non-ASCII (nukta, ZWJ, etc.)
        4. Lowercase
        5. Collapse whitespace

    Returns
    -------
    str : ASCII-only, lowercased, single-spaced romanised text.
    """
    sanscript, transliterate = _import_transliteration()

    # NFC normalise to merge combining characters
    text = unicodedata.normalize('NFC', text)

    # Transliterate Bengali → ITRANS
    roman = transliterate(text, sanscript.BENGALI, sanscript.ITRANS)

    # Strip residual non-ASCII (nukta ়, ZWJ, ZWNJ, etc.)
    roman = _STRAY_UNICODE.sub('', roman)

    # Lowercase + collapse spaces
    roman = roman.lower().strip()
    roman = _MULTI_SPACE.sub(' ', roman)

    return roman


def transliterate_file(
    input_path: str,
    output_path: str,
    is_tsv: bool = False,
    text_col: int = 2,  # 0-indexed column for text in TSV
    max_sentences: Optional[int] = None,
    min_tokens: int = 3,  # skip very short sentences
) -> int:
    """
    Read Bengali text (plain or TSV), transliterate, write one sentence per line.

    Parameters
    ----------
    input_path : path to Bengali text file
    output_path : path for romanised output
    is_tsv : if True, extract text from column `text_col`
    text_col : 0-indexed column index for Bengali text in TSV
    max_sentences : cap output size (None = no limit)
    min_tokens : minimum word count to keep a sentence

    Returns
    -------
    int : number of sentences written
    """
    count = 0
    with open(input_path, 'r', encoding='utf-8') as fin, \
         open(output_path, 'w', encoding='utf-8') as fout:

        for line in fin:
            line = line.strip()
            if not line:
                continue

            # Extract Bengali text
            if is_tsv:
                parts = line.split('\t')
                if len(parts) <= text_col:
                    continue
                bengali_text = parts[text_col]
            else:
                bengali_text = line

            # Skip lines that are mostly ASCII (headers, metadata)
            bengali_chars = sum(1 for c in bengali_text if '\u0980' <= c <= '\u09FF')
            if bengali_chars < 3:
                continue

            # Transliterate
            roman = transliterate_bengali(bengali_text)

            # Quality filter
            tokens = roman.split()
            if len(tokens) < min_tokens:
                continue

            fout.write(roman + '\n')
            count += 1

            if max_sentences and count >= max_sentences:
                break

    return count


# ═══════════════════════════════════════════════════════════════════════════
# Part 2: Download OpenSLR-53 (Standard Bengali — corpus DB)
# ═══════════════════════════════════════════════════════════════════════════

OPENSLR53_BASE = "https://www.openslr.org/resources/53"
OPENSLR53_TSV  = f"{OPENSLR53_BASE}/utt_spk_text.tsv"
OPENSLR53_ZIPS = [f"{OPENSLR53_BASE}/asr_bengali_{i}.zip" for i in
                  list("0123456789") + list("abcdef")]

def download_file(url: str, dest: str, desc: str = "") -> str:
    """Download a file with progress bar. Returns path to downloaded file."""
    import requests
    from tqdm import tqdm

    if os.path.exists(dest):
        print(f"  [skip] Already exists: {dest}")
        return dest

    print(f"  Downloading {desc or url} ...")
    resp = requests.get(url, stream=True, timeout=60)
    resp.raise_for_status()
    total = int(resp.headers.get('content-length', 0))

    os.makedirs(os.path.dirname(dest) or '.', exist_ok=True)
    with open(dest, 'wb') as f, tqdm(total=total, unit='B', unit_scale=True, desc=desc) as pbar:
        for chunk in resp.iter_content(chunk_size=8192):
            f.write(chunk)
            pbar.update(len(chunk))

    return dest


def download_openslr53(
    download_dir: str,
    zip_count: int = 2,
) -> str:
    """
    Download the OpenSLR-53 transcription TSV.

    We only need the TSV (15MB) for DB text — the audio zips are optional
    since OpenSLR-53 already provides transcriptions. Audio zips are only
    needed if you want to re-run Whisper on standard Bengali for comparison.

    Parameters
    ----------
    download_dir : where to save downloaded files
    zip_count : number of audio zips to download (0 = TSV only, for text)

    Returns
    -------
    str : path to the TSV file
    """
    os.makedirs(download_dir, exist_ok=True)

    # Always download the TSV (text transcriptions)
    tsv_path = os.path.join(download_dir, "utt_spk_text.tsv")
    download_file(OPENSLR53_TSV, tsv_path, desc="OpenSLR-53 transcriptions")

    # Optionally download audio zips (for Whisper re-transcription)
    if zip_count > 0:
        for i, url in enumerate(OPENSLR53_ZIPS[:zip_count]):
            zip_name = url.split('/')[-1]
            zip_path = os.path.join(download_dir, zip_name)
            download_file(url, zip_path, desc=f"Audio zip {i+1}/{zip_count}")

    return tsv_path


def process_openslr53(
    tsv_path: str,
    output_path: str,
    max_sentences: Optional[int] = None,
) -> int:
    """
    Process OpenSLR-53 TSV → transliterated corpus_b.txt.

    TSV format: utterance_id \t speaker_id \t bengali_text
    """
    print(f"\nProcessing OpenSLR-53 TSV → {output_path}")
    count = transliterate_file(
        input_path=tsv_path,
        output_path=output_path,
        is_tsv=True,
        text_col=2,  # 3rd column = Bengali text
        max_sentences=max_sentences,
        min_tokens=3,
    )
    print(f"  Wrote {count:,} sentences to {output_path}")
    return count


# ═══════════════════════════════════════════════════════════════════════════
# Part 3: Whisper ASR on dialect audio (DA)
# ═══════════════════════════════════════════════════════════════════════════

AUDIO_EXTENSIONS = {'.wav', '.mp3', '.flac', '.ogg', '.m4a', '.opus', '.webm'}

def find_audio_files(audio_dir: str) -> List[str]:
    """Recursively find all audio files in a directory."""
    files = []
    for ext in AUDIO_EXTENSIONS:
        files.extend(glob.glob(os.path.join(audio_dir, '**', f'*{ext}'), recursive=True))
    files.sort()
    return files


def whisper_transcribe_directory(
    audio_dir: str,
    output_path: str,
    model_name: str = "large-v3",
    language: str = "bn",
    batch_log_every: int = 10,
    max_files: Optional[int] = None,
) -> int:
    """
    Run Whisper ASR on all audio files in a directory, transliterate output,
    and write one sentence per line to output_path.

    Whisper segments audio into sentences automatically via its internal VAD.
    Each segment becomes one line in the output corpus.

    Parameters
    ----------
    audio_dir : directory containing audio files
    output_path : path for romanised output corpus
    model_name : Whisper model size (tiny/base/small/medium/large-v3)
    language : ISO code for Bengali
    batch_log_every : log progress every N files
    max_files : cap number of files to process (None = all)

    Returns
    -------
    int : total sentences written
    """
    whisper = _import_whisper()
    from tqdm import tqdm

    audio_files = find_audio_files(audio_dir)
    if not audio_files:
        print(f"  ERROR: No audio files found in {audio_dir}")
        print(f"  Supported formats: {', '.join(sorted(AUDIO_EXTENSIONS))}")
        return 0

    if max_files:
        audio_files = audio_files[:max_files]

    print(f"\n  Found {len(audio_files)} audio files in {audio_dir}")
    print(f"  Loading Whisper model '{model_name}' ...")
    model = whisper.load_model(model_name)
    print(f"  Model loaded. Starting transcription ...\n")

    total_sentences = 0
    failed_files = []

    # Also save raw Bengali transcriptions for reference
    raw_output = output_path.replace('.txt', '_raw_bengali.txt')

    with open(output_path, 'w', encoding='utf-8') as fout, \
         open(raw_output, 'w', encoding='utf-8') as fraw:

        for i, audio_path in enumerate(tqdm(audio_files, desc="Whisper ASR")):
            try:
                # Transcribe with Whisper
                result = model.transcribe(
                    audio_path,
                    language=language,
                    task="transcribe",     # transcribe (not translate)
                    verbose=False,
                    word_timestamps=False,
                    condition_on_previous_text=True,
                )

                # Process each segment as a sentence
                for seg in result.get("segments", []):
                    bengali_text = seg["text"].strip()
                    if not bengali_text:
                        continue

                    # Save raw Bengali
                    fraw.write(bengali_text + '\n')

                    # Transliterate to roman
                    roman = transliterate_bengali(bengali_text)
                    tokens = roman.split()

                    # Quality filter: skip very short or empty
                    if len(tokens) >= 3:
                        fout.write(roman + '\n')
                        total_sentences += 1

            except Exception as e:
                failed_files.append((audio_path, str(e)))
                continue

    # Report
    print(f"\n  Transcription complete:")
    print(f"    Total sentences:  {total_sentences:,}")
    print(f"    Failed files:     {len(failed_files)}")
    print(f"    Romanised output: {output_path}")
    print(f"    Raw Bengali:      {raw_output}")

    if failed_files:
        fail_log = output_path.replace('.txt', '_failures.log')
        with open(fail_log, 'w') as f:
            for path, err in failed_files:
                f.write(f"{path}\t{err}\n")
        print(f"    Failure log:      {fail_log}")

    return total_sentences


# ═══════════════════════════════════════════════════════════════════════════
# Part 4: Corpus statistics & validation
# ═══════════════════════════════════════════════════════════════════════════

def corpus_stats(path: str, label: str) -> dict:
    """Print and return basic corpus statistics."""
    from collections import Counter

    sentences = []
    token_counter = Counter()

    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            tokens = line.strip().split()
            if tokens:
                sentences.append(tokens)
                token_counter.update(tokens)

    n_sent = len(sentences)
    n_tokens = sum(len(s) for s in sentences)
    n_types = len(token_counter)
    avg_len = n_tokens / n_sent if n_sent else 0
    freq5_types = sum(1 for w, c in token_counter.items() if c >= 5)

    print(f"\n  ── {label} ──")
    print(f"    Sentences:           {n_sent:>10,}")
    print(f"    Total tokens:        {n_tokens:>10,}")
    print(f"    Unique types:        {n_types:>10,}")
    print(f"    Types with freq≥5:   {freq5_types:>10,}")
    print(f"    Avg sentence length: {avg_len:>10.1f} tokens")
    print(f"    Top-20 tokens:       {', '.join(w for w, _ in token_counter.most_common(20))}")

    return {
        'sentences': n_sent,
        'tokens': n_tokens,
        'types': n_types,
        'freq5_types': freq5_types,
        'avg_len': avg_len,
        'top20': [w for w, _ in token_counter.most_common(20)],
    }


# ═══════════════════════════════════════════════════════════════════════════
# Part 5: Pre-transcribed dialect text (alternative to Whisper)
# ═══════════════════════════════════════════════════════════════════════════

def process_pretranscribed_da(
    text_path: str,
    output_path: str,
    is_bengali_script: bool = True,
    max_sentences: Optional[int] = None,
) -> int:
    """
    Process pre-transcribed dialect text (if you have text but not audio).

    Handles:
      - Bengali script → transliterate
      - Already romanised → just clean and lowercase

    Parameters
    ----------
    text_path : path to dialect text file (one sentence per line)
    output_path : path for cleaned output
    is_bengali_script : True if text is in Bengali script, False if romanised
    max_sentences : cap output
    """
    if is_bengali_script:
        count = transliterate_file(
            input_path=text_path,
            output_path=output_path,
            is_tsv=False,
            max_sentences=max_sentences,
            min_tokens=3,
        )
    else:
        # Already romanised — just clean
        count = 0
        with open(text_path, 'r', encoding='utf-8') as fin, \
             open(output_path, 'w', encoding='utf-8') as fout:
            for line in fin:
                cleaned = _MULTI_SPACE.sub(' ', line.lower().strip())
                if len(cleaned.split()) >= 3:
                    fout.write(cleaned + '\n')
                    count += 1
                    if max_sentences and count >= max_sentences:
                        break

    print(f"  Wrote {count:,} sentences to {output_path}")
    return count


# ═══════════════════════════════════════════════════════════════════════════
# CLI Entry Point
# ═══════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Audio → Transliterated Text pipeline for Bengali dialect divergence project",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Full pipeline
  python asr_pipeline.py --da-audio-dir ~/dialect_audio --output-dir ../data

  # DB only (download + transliterate OpenSLR-53)
  python asr_pipeline.py --output-dir ../data --skip-da

  # DA only (Whisper on your audio)
  python asr_pipeline.py --da-audio-dir ~/dialect_audio --output-dir ../data --skip-db

  # DA from pre-transcribed Bengali text (no audio/Whisper needed)
  python asr_pipeline.py --da-text ~/dialect_sentences.txt --output-dir ../data --skip-db
        """,
    )

    # ── DA (dialect) source ──
    da_group = parser.add_mutually_exclusive_group()
    da_group.add_argument('--da-audio-dir', type=str,
        help='Directory containing rural dialect audio files for Whisper ASR')
    da_group.add_argument('--da-text', type=str,
        help='Pre-transcribed dialect text file (Bengali script, one sent/line)')

    # ── DB (standard) source ──
    parser.add_argument('--db-tsv', type=str, default=None,
        help='Path to existing OpenSLR-53 utt_spk_text.tsv (skip download)')

    # ── Output ──
    parser.add_argument('--output-dir', type=str, default='../data',
        help='Output directory for corpus_a.txt and corpus_b.txt (default: ../data)')

    # ── Control ──
    parser.add_argument('--skip-da', action='store_true',
        help='Skip DA (dialect) processing')
    parser.add_argument('--skip-db', action='store_true',
        help='Skip DB (standard) processing')

    # ── Whisper settings ──
    parser.add_argument('--whisper-model', type=str, default='large-v3',
        choices=['tiny', 'base', 'small', 'medium', 'large', 'large-v2', 'large-v3'],
        help='Whisper model size (default: large-v3)')
    parser.add_argument('--max-audio-files', type=int, default=None,
        help='Cap number of audio files to process')

    # ── OpenSLR settings ──
    parser.add_argument('--openslr-zip-count', type=int, default=0,
        help='Number of OpenSLR-53 audio zips to download (0=TSV only, default: 0)')
    parser.add_argument('--download-dir', type=str, default='../data/openslr53_raw',
        help='Where to download OpenSLR-53 files')

    # ── Corpus size ──
    parser.add_argument('--max-da-sentences', type=int, default=None,
        help='Cap DA corpus size')
    parser.add_argument('--max-db-sentences', type=int, default=None,
        help='Cap DB corpus size')

    args = parser.parse_args()

    print("=" * 70)
    print("Bengali Dialect → English: ASR & Transliteration Pipeline")
    print("=" * 70)

    os.makedirs(args.output_dir, exist_ok=True)
    corpus_a_path = os.path.join(args.output_dir, 'corpus_a.txt')  # DA = dialect
    corpus_b_path = os.path.join(args.output_dir, 'corpus_b.txt')  # DB = standard

    # ──────────────────────────────────────────────────────────────────
    # Process DB (Standard Bengali — OpenSLR-53)
    # ──────────────────────────────────────────────────────────────────
    if not args.skip_db:
        print(f"\n{'─'*70}")
        print("STEP 1: DB (Standard Bengali) — OpenSLR-53")
        print(f"{'─'*70}")

        if args.db_tsv:
            tsv_path = args.db_tsv
            print(f"  Using existing TSV: {tsv_path}")
        else:
            tsv_path = download_openslr53(
                download_dir=args.download_dir,
                zip_count=args.openslr_zip_count,
            )

        n_db = process_openslr53(
            tsv_path=tsv_path,
            output_path=corpus_b_path,
            max_sentences=args.max_db_sentences,
        )

        corpus_stats(corpus_b_path, "DB (Standard Bengali)")
    else:
        print("\n  [skip] DB processing skipped (--skip-db)")

    # ──────────────────────────────────────────────────────────────────
    # Process DA (Rural Dialect)
    # ──────────────────────────────────────────────────────────────────
    if not args.skip_da:
        print(f"\n{'─'*70}")
        print("STEP 2: DA (Rural Bengali Dialect)")
        print(f"{'─'*70}")

        if args.da_audio_dir:
            # Whisper ASR pathway
            print(f"  Source: Audio directory → Whisper ASR")
            print(f"  Model: {args.whisper_model}")
            print(f"  Audio dir: {args.da_audio_dir}")

            n_da = whisper_transcribe_directory(
                audio_dir=args.da_audio_dir,
                output_path=corpus_a_path,
                model_name=args.whisper_model,
                max_files=args.max_audio_files,
            )

        elif args.da_text:
            # Pre-transcribed text pathway
            print(f"  Source: Pre-transcribed Bengali text")
            print(f"  Input: {args.da_text}")

            n_da = process_pretranscribed_da(
                text_path=args.da_text,
                output_path=corpus_a_path,
                is_bengali_script=True,
                max_sentences=args.max_da_sentences,
            )

        else:
            print("  ERROR: Provide --da-audio-dir or --da-text for dialect corpus")
            print("         Or use --skip-da to skip dialect processing")
            sys.exit(1)

        corpus_stats(corpus_a_path, "DA (Rural Bengali Dialect)")
    else:
        print("\n  [skip] DA processing skipped (--skip-da)")

    # ──────────────────────────────────────────────────────────────────
    # Summary
    # ──────────────────────────────────────────────────────────────────
    print(f"\n{'═'*70}")
    print("PIPELINE COMPLETE")
    print(f"{'═'*70}")

    if not args.skip_da and os.path.exists(corpus_a_path):
        print(f"  DA (dialect):   {corpus_a_path}")
    if not args.skip_db and os.path.exists(corpus_b_path):
        print(f"  DB (standard):  {corpus_b_path}")

    print(f"\n  Next step: feed these into data_utils.py → sgns.py")
    print(f"  Usage:  from data_utils import load_corpus, build_vocab")
    print(f"          corpus_a = load_corpus('{corpus_a_path}')")
    print(f"          corpus_b = load_corpus('{corpus_b_path}')")


if __name__ == "__main__":
    main()
