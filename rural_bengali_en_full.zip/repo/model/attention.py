"""
attention.py
------------
Scaled Dot-Product Attention & Multi-Head Attention Analysis.

Assignment 2, Part III (Problems 3.1–3.3) — Avnish (Lead Owner)

Research relevance: Scaled dot-product attention is the central operation
of the transformer architecture used for Bengali dialect translation.

Usage:
    python attention.py

Outputs:
    outputs/attn_heatmap.png          — Attention weight heatmap
    outputs/attn_test_output.txt      — Full test case printout
    outputs/attn_scaling_plot.png     — std(QK^T) vs d_k experiment
    outputs/attn_multihead_analysis.txt — Multi-head analysis writeup

Authors: Avnish (A2 Part III lead)
"""

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from typing import Tuple


# ═══════════════════════════════════════════════════════════════════════════
# Problem 3.1: Scaled Dot-Product Attention
# ═══════════════════════════════════════════════════════════════════════════

def softmax(x: np.ndarray, axis: int = -1) -> np.ndarray:
    """
    Row-wise softmax with numerical stability.

    softmax(xᵢ) = exp(xᵢ - max(x)) / Σ exp(xⱼ - max(x))
    """
    x_shifted = x - np.max(x, axis=axis, keepdims=True)
    exp_x = np.exp(x_shifted)
    return exp_x / np.sum(exp_x, axis=axis, keepdims=True)


def attention(
    Q: np.ndarray,
    K: np.ndarray,
    V: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Scaled Dot-Product Attention (NumPy, no nn.MultiheadAttention).

    Attention(Q, K, V) = softmax(Q K^T / √d_k) V

    Steps:
        1. Score matrix: S = Q K^T
        2. Scaled scores: S / √d_k
        3. Row-wise softmax → attention weights
        4. Weighted sum: output = weights · V

    Parameters
    ----------
    Q : query matrix,  shape (n_q, d_k)
    K : key matrix,    shape (n_k, d_k)
    V : value matrix,  shape (n_k, d_v)

    Returns
    -------
    output          : (n_q, d_v)
    attention_weights : (n_q, n_k)
    raw_scores      : (n_q, n_k) — before scaling
    scaled_scores   : (n_q, n_k) — after scaling, before softmax
    """
    d_k = Q.shape[-1]

    # Step 1: Similarity scores
    raw_scores = Q @ K.T  # (n_q, n_k)

    # Step 2: Scale by √d_k
    scaled_scores = raw_scores / np.sqrt(d_k)

    # Step 3: Row-wise softmax
    attention_weights = softmax(scaled_scores, axis=-1)  # (n_q, n_k)

    # Step 4: Weighted sum of values
    output = attention_weights @ V  # (n_q, d_v)

    return output, attention_weights, raw_scores, scaled_scores


def format_matrix(name: str, M: np.ndarray, precision: int = 4) -> str:
    """Format a matrix for pretty printing."""
    lines = [f"  {name} (shape {M.shape}):"]
    for row in M:
        vals = "  ".join(f"{v:>{precision+3}.{precision}f}" for v in row)
        lines.append(f"    [{vals}]")
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════
# Problem 3.2: Why Scale by √d_k?
# ═══════════════════════════════════════════════════════════════════════════

SCALING_PROOF = r"""
PROBLEM 3.2: WHY SCALE BY √d_k?
========================================================================

Claim: If q_i, k_i ~ iid(0, 1), then E[q^T k] = 0 and Var(q^T k) = d_k.

Proof:

Let q = (q₁, ..., q_{d_k}) and k = (k₁, ..., k_{d_k}) where each
q_i, k_i are independent with mean 0 and variance 1.

The dot product is:
    q^T k = Σ_{i=1}^{d_k} q_i k_i

Expected value:
    E[q^T k] = E[Σ q_i k_i]
             = Σ E[q_i k_i]
             = Σ E[q_i] E[k_i]      (independence)
             = Σ 0 · 0
             = 0                     ∎

Variance:
    Var(q^T k) = Var(Σ q_i k_i)
               = Σ Var(q_i k_i)      (independence of terms)

    For each term:
    Var(q_i k_i) = E[(q_i k_i)²] - (E[q_i k_i])²
                 = E[q_i²] E[k_i²] - 0
                 = Var(q_i) · Var(k_i)     (since E[q_i] = E[k_i] = 0)
                 = 1 · 1 = 1

    Therefore:
    Var(q^T k) = Σ_{i=1}^{d_k} 1 = d_k    ∎

Consequence:
    std(q^T k) = √d_k

    As d_k grows, the dot products grow in magnitude (std scales as √d_k),
    pushing softmax inputs into regions where gradients are extremely small
    (near 0 or 1 in the saturation zones).

    Dividing by √d_k normalises the variance back to 1:
        Var(q^T k / √d_k) = Var(q^T k) / d_k = d_k / d_k = 1

    This keeps softmax in its sensitive region, ensuring:
    1. Gradients flow effectively during backpropagation
    2. Attention weights are not overly peaked (one position gets all weight)
    3. The model can attend to multiple positions simultaneously
"""


def run_scaling_experiment(output_dir: str, seed: int = 42):
    """
    Experiment: generate random Q, K for d_k ∈ {16, 64, 256, 1024};
    plot std(QK^T) vs d_k; verify ≈ √d_k.
    """
    rng = np.random.default_rng(seed)
    dims = [4, 8, 16, 32, 64, 128, 256, 512, 1024]
    n = 100  # number of queries/keys

    measured_stds = []
    theoretical_stds = []

    for d_k in dims:
        Q = rng.standard_normal((n, d_k))
        K = rng.standard_normal((n, d_k))
        scores = Q @ K.T
        measured_stds.append(np.std(scores))
        theoretical_stds.append(np.sqrt(d_k))

    # Plot
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(dims, measured_stds, 'o-', color="#FF5722", linewidth=2,
            markersize=8, label="Measured std(QK$^T$)")
    ax.plot(dims, theoretical_stds, 's--', color="#2196F3", linewidth=2,
            markersize=6, label="Theoretical √$d_k$")
    ax.set_xlabel("$d_k$ (key dimension)", fontsize=12)
    ax.set_ylabel("std(QK$^T$)", fontsize=12)
    ax.set_title("Problem 3.2: Dot-Product Variance Scales with $d_k$", fontsize=14)
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    ax.set_xscale("log", base=2)
    ax.set_yscale("log", base=2)

    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, "attn_scaling_plot.png"), dpi=150)
    plt.close(fig)

    print(f"\n  Scaling experiment:")
    print(f"    {'d_k':>6s}  {'measured':>10s}  {'√d_k':>10s}  {'ratio':>8s}")
    print(f"    {'─'*6}  {'─'*10}  {'─'*10}  {'─'*8}")
    for d, m, t in zip(dims, measured_stds, theoretical_stds):
        print(f"    {d:6d}  {m:10.4f}  {t:10.4f}  {m/t:8.4f}")
    print(f"\n  Plot saved → attn_scaling_plot.png")


# ═══════════════════════════════════════════════════════════════════════════
# Problem 3.3: Multi-Head Attention Analysis
# ═══════════════════════════════════════════════════════════════════════════

MULTIHEAD_ANALYSIS = """
PROBLEM 3.3: WHY h HEADS OF DIMENSION d_v OUTPERFORM ONE HEAD OF h·d_v
========================================================================

Theoretical Argument:

A single attention head computes one set of attention weights — a single
"soft routing" pattern from queries to keys. This pattern must encode
ALL relevant relationships in a single weighted average. For complex
dependencies (e.g., subject-verb agreement + positional proximity +
semantic similarity), a single pattern is a Procrustes fit: it can only
capture the dominant relationship and ignores orthogonal ones.

Multi-head attention with h heads of dimension d_v each computes h
INDEPENDENT attention patterns, each operating in its own learned
subspace. This allows:

1. PARALLEL SPECIALISATION: Different heads learn different relationship
   types. Empirically, in trained transformer models:
   - Some heads attend to the previous/next token (local context)
   - Some heads attend to syntactically linked tokens (long-range)
   - Some heads attend to semantically related tokens
   A single head of dimension h·d_v cannot decompose these — it must
   average them into one pattern.

2. RANK ADVANTAGE: The output of multi-head attention is:
       MultiHead(Q,K,V) = Concat(head₁, ..., headₕ) W^O
   Each headᵢ = Attention(Q Wᵢ^Q, K Wᵢ^K, V Wᵢ^V).

   The concatenated output has rank up to h (one per head), while a
   single-head output has rank 1 (one attention-weighted average).
   The final linear projection W^O can recombine these h rank-1
   components, giving the output effective rank h — a strictly richer
   representation than a single head.

3. SUBSPACE DIVERSITY: Each head projects Q, K, V into a d_v-dimensional
   subspace via learned Wᵢ^Q, Wᵢ^K, Wᵢ^V. These projections can be
   nearly orthogonal, meaning different heads attend based on different
   FEATURES of the same tokens. One head might use positional features,
   another morphological features. A single large head uses one
   projection for all features — conflating signals.

4. REGULARISATION EFFECT: With h independent attention computations,
   no single head must capture everything. This distributes the
   representational load and acts as implicit regularisation, similar
   to dropout or ensemble averaging. The model is less likely to
   overfit to one dominant attention pattern.

Intuitive Explanation:

Imagine you're translating a Bengali sentence. You need to track:
  (a) Which word is the verb's subject (syntactic)
  (b) Whether a word is dialect or standard (lexical)
  (c) Where the word sits in the sentence (positional)

One head with a big d_v must somehow encode all three signals in a
single weighted average — it will probably focus on (a) and lose (b)
and (c). Four heads can each handle one relationship type independently.
The final W^O projection combines them. This is why multi-head attention
consistently outperforms single-head across model sizes and tasks.

Cost comparison:

Single head: Q,K,V ∈ R^{n × h·d_v}, attention O(n² · h·d_v)
Multi-head:  h heads × (Q,K,V ∈ R^{n × d_v}, attention O(n² · d_v))
           = O(n² · h·d_v)

Total computation is identical. Multi-head is not more expensive — it
simply restructures the same parameter budget into a more expressive
architecture.
"""


# ═══════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════

def main():
    output_dir = "outputs"
    os.makedirs(output_dir, exist_ok=True)

    print("=" * 70)
    print("A2 PART III: ATTENTION MECHANISMS")
    print("=" * 70)

    # ── Problem 3.1: Scaled Dot-Product Attention ─────────────────
    print("\n" + "─" * 70)
    print("PROBLEM 3.1: Scaled Dot-Product Attention")
    print("─" * 70)

    # Test matrices per roadmap: 2×2 Q, 3×2 K, 3×2 V
    Q = np.array([[1.0, 0.0],
                  [0.0, 1.0]])

    K = np.array([[1.0, 0.0],
                  [0.0, 1.0],
                  [1.0, 1.0]])

    V = np.array([[1.0, 2.0],
                  [3.0, 4.0],
                  [5.0, 6.0]])

    output, weights, raw_scores, scaled_scores = attention(Q, K, V)

    test_output = []
    test_output.append("\nInput matrices:")
    test_output.append(format_matrix("Q (queries)", Q))
    test_output.append(format_matrix("K (keys)", K))
    test_output.append(format_matrix("V (values)", V))
    test_output.append(f"\n  d_k = {Q.shape[-1]}, √d_k = {np.sqrt(Q.shape[-1]):.4f}")
    test_output.append("\nStep-by-step computation:")
    test_output.append(format_matrix("1. Raw scores S = QK^T", raw_scores))
    test_output.append(format_matrix("2. Scaled scores S/√d_k", scaled_scores))
    test_output.append(format_matrix("3. Attention weights (softmax)", weights))
    test_output.append(format_matrix("4. Output = weights · V", output))

    text = "\n".join(test_output)
    print(text)

    # Interpretation
    interp = []
    interp.append("\nInterpretation:")
    for i in range(Q.shape[0]):
        max_j = np.argmax(weights[i])
        interp.append(f"  Query {i} attends most to Key {max_j} "
                      f"(weight={weights[i, max_j]:.4f})")
        for j in range(K.shape[0]):
            interp.append(f"    → Key {j}: weight={weights[i,j]:.4f}, "
                          f"raw_score={raw_scores[i,j]:.4f}")

    interp_text = "\n".join(interp)
    print(interp_text)

    with open(os.path.join(output_dir, "attn_test_output.txt"), "w") as f:
        f.write("PROBLEM 3.1: SCALED DOT-PRODUCT ATTENTION\n")
        f.write("=" * 70 + "\n")
        f.write(text + "\n")
        f.write(interp_text + "\n")

    # ── Attention heatmap ─────────────────────────────────────────
    fig, axes = plt.subplots(1, 3, figsize=(14, 4))

    # Raw scores
    im0 = axes[0].imshow(raw_scores, cmap="YlOrRd", aspect="auto")
    axes[0].set_title("Raw Scores (QK$^T$)", fontsize=12)
    axes[0].set_xlabel("Key position")
    axes[0].set_ylabel("Query position")
    plt.colorbar(im0, ax=axes[0], shrink=0.8)
    for i in range(raw_scores.shape[0]):
        for j in range(raw_scores.shape[1]):
            axes[0].text(j, i, f"{raw_scores[i,j]:.2f}",
                        ha="center", va="center", fontsize=10)

    # Scaled scores
    im1 = axes[1].imshow(scaled_scores, cmap="YlOrRd", aspect="auto")
    axes[1].set_title("Scaled Scores (QK$^T$/√$d_k$)", fontsize=12)
    axes[1].set_xlabel("Key position")
    plt.colorbar(im1, ax=axes[1], shrink=0.8)
    for i in range(scaled_scores.shape[0]):
        for j in range(scaled_scores.shape[1]):
            axes[1].text(j, i, f"{scaled_scores[i,j]:.2f}",
                        ha="center", va="center", fontsize=10)

    # Attention weights
    im2 = axes[2].imshow(weights, cmap="YlOrRd", aspect="auto")
    axes[2].set_title("Attention Weights", fontsize=12)
    axes[2].set_xlabel("Key position")
    plt.colorbar(im2, ax=axes[2], shrink=0.8)
    for i in range(weights.shape[0]):
        for j in range(weights.shape[1]):
            axes[2].text(j, i, f"{weights[i,j]:.3f}",
                        ha="center", va="center", fontsize=10)

    fig.suptitle("Problem 3.1: Scaled Dot-Product Attention Visualization",
                 fontsize=14, fontweight="bold")
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, "attn_heatmap.png"), dpi=150)
    plt.close(fig)
    print(f"\n  Heatmap saved → attn_heatmap.png")

    # ── Problem 3.2: Scaling Experiment ───────────────────────────
    print("\n" + "─" * 70)
    print("PROBLEM 3.2: Why Scale by √d_k?")
    print("─" * 70)

    print(SCALING_PROOF)
    run_scaling_experiment(output_dir)

    with open(os.path.join(output_dir, "attn_scaling_proof.txt"), "w") as f:
        f.write(SCALING_PROOF)

    # ── Problem 3.3: Multi-Head Analysis ──────────────────────────
    print("\n" + "─" * 70)
    print("PROBLEM 3.3: Multi-Head Attention Analysis")
    print("─" * 70)

    print(MULTIHEAD_ANALYSIS)

    with open(os.path.join(output_dir, "attn_multihead_analysis.txt"), "w") as f:
        f.write(MULTIHEAD_ANALYSIS)

    print(f"\n{'='*70}")
    print("PART III COMPLETE")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
