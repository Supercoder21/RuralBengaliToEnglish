"""
levenshtein.py
--------------
Levenshtein Edit Distance — Implementation, Corpus Analysis, and Proof.

Assignment 2, Part I (Problems 1.1–1.3) — Avnish (Lead Owner)

Research relevance: Levenshtein distance gives a character-level baseline
for measuring how far a dialectal word is from its standard counterpart.
This motivates using character-level features in ASR and translation models.

Usage:
    python levenshtein.py

Outputs:
    outputs/lev_dp_matrix.txt         — DP matrix printout for test pair
    outputs/lev_corpus_histogram.png  — Corpus-level distance distribution
    outputs/lev_corpus_stats.txt      — Mean, std, per-pair distances
    outputs/lev_triangle_proof.txt    — Triangle inequality proof

Authors: Avnish (A2 Part I lead)
"""

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from typing import Tuple, List


# ═══════════════════════════════════════════════════════════════════════════
# Problem 1.1: Levenshtein Distance Implementation
# ═══════════════════════════════════════════════════════════════════════════

def levenshtein(s1: str, s2: str) -> Tuple[int, np.ndarray]:
    """
    Compute the Levenshtein edit distance between two strings.

    Uses the standard dynamic programming algorithm:

        d(i, j) = | i                                  if j = 0
                   | j                                  if i = 0
                   | d(i-1, j-1)                        if s1[i] = s2[j]
                   | 1 + min(d(i-1,j), d(i,j-1), d(i-1,j-1))  otherwise

    Operations: insertion (d(i, j-1) + 1), deletion (d(i-1, j) + 1),
    substitution (d(i-1, j-1) + 1).

    Time complexity:  O(m × n)
    Space complexity: O(m × n) for full DP matrix

    Parameters
    ----------
    s1 : source string
    s2 : target string

    Returns
    -------
    (distance, dp_matrix) : int distance and full (m+1) × (n+1) DP matrix
    """
    m, n = len(s1), len(s2)
    dp = np.zeros((m + 1, n + 1), dtype=int)

    # Base cases
    for i in range(m + 1):
        dp[i, 0] = i
    for j in range(n + 1):
        dp[0, j] = j

    # Fill DP table
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if s1[i - 1] == s2[j - 1]:
                dp[i, j] = dp[i - 1, j - 1]  # match — no cost
            else:
                dp[i, j] = 1 + min(
                    dp[i - 1, j],      # deletion
                    dp[i, j - 1],      # insertion
                    dp[i - 1, j - 1],  # substitution
                )

    return int(dp[m, n]), dp


def format_dp_matrix(s1: str, s2: str, dp: np.ndarray) -> str:
    """Format DP matrix as a readable string with row/column labels."""
    m, n = len(s1), len(s2)
    lines = []

    # Header row
    header = "     " + "  ".join(f"{c:>3s}" for c in ["ε"] + list(s2))
    lines.append(header)
    lines.append("  " + "─" * (len(header) - 2))

    # Data rows
    row_labels = ["ε"] + list(s1)
    for i in range(m + 1):
        row = f"{row_labels[i]:>2s} │ " + "  ".join(f"{dp[i, j]:3d}" for j in range(n + 1))
        lines.append(row)

    return "\n".join(lines)


def normalized_distance(s1: str, s2: str) -> float:
    """
    Normalised Levenshtein distance: d(s1, s2) / max(|s1|, |s2|).
    Returns value in [0, 1].
    """
    d, _ = levenshtein(s1, s2)
    max_len = max(len(s1), len(s2))
    return d / max_len if max_len > 0 else 0.0


# ═══════════════════════════════════════════════════════════════════════════
# Problem 1.2: Corpus-Level Divergence
# ═══════════════════════════════════════════════════════════════════════════

# 20 dialect–standard Bengali transliterated sentence pairs
# Format: (dialect_itrans, standard_itrans, english_gloss)
# These represent genuine Purulia/Manbhumi → Standard Bengali shifts
DIALECT_STANDARD_PAIRS = [
    # Lexical shifts
    ("ami hata geli macha kinte", "ami bajare gelama macha kinte",
     "I went to market to buy fish"),
    ("po ta kothae gelo", "chhele ta kothaya gelo",
     "Where did the boy go"),
    ("nok gula kharap", "lok gulo kharap",
     "The people are bad"),
    ("ham to jai na", "ami to jai na",
     "I don't go"),
    ("tui ki khas re", "tumi ki khachho",
     "What are you eating"),
    # Phonological shifts
    ("ami ghare achi", "ami ghare achhi",
     "I am at home"),
    ("mati te bij buno", "matite bij buno",
     "Sow seeds in the soil"),
    ("gorai nodi te nauka chale", "garai nadite nauka chale",
     "Boats run on Garai river"),
    ("amra cha khaitam", "amra cha khetam",
     "We used to drink tea"),
    ("brishti haile chash habe", "brishti hale chash habe",
     "If it rains farming will happen"),
    # Morphological shifts
    ("karite parbo na", "karte parbo na",
     "I won't be able to do it"),
    ("dekhi ni kono din", "dekhini kono din",
     "Never seen it"),
    ("se ase ni ajo", "se aseni aaj o",
     "He hasn't come today either"),
    ("amar bhai ta elo", "amar bhai ta elo",
     "My brother came"),
    ("khabar dilo na keu", "khabar dilo na keu",
     "Nobody gave food"),
    # Syntactic / word order
    ("ki koro tumi akhon", "tumi akhon ki korcho",
     "What are you doing now"),
    ("jole gelo pore", "jale gelo pore",
     "Fell into water later"),
    ("dhan kata holo shesh", "dhaner kata shesh holo",
     "Rice cutting finished"),
    ("rasta ta bhalo na re", "rasta ta bhalo na",
     "The road is not good"),
    ("goru charate mathe gelo", "goru charate mathe gechhe",
     "Went to graze cattle in the field"),
]


def run_corpus_analysis(
    pairs: List[Tuple[str, str, str]],
    output_dir: str,
) -> Tuple[float, float, List[float]]:
    """
    Compute corpus-level Levenshtein divergence.

    d̄ = (1/n) Σ d_norm(dᵢ, sᵢ)

    Returns (mean, std, list_of_distances).
    """
    distances = []
    raw_distances = []

    lines = []
    lines.append(f"{'#':>3s}  {'d':>3s}  {'d_norm':>6s}  {'Dialect':30s}  {'Standard':30s}  Gloss")
    lines.append("─" * 120)

    for i, (dialect, standard, gloss) in enumerate(pairs, 1):
        d, dp = levenshtein(dialect, standard)
        d_norm = d / max(len(dialect), len(standard))
        distances.append(d_norm)
        raw_distances.append(d)
        lines.append(
            f"{i:3d}  {d:3d}  {d_norm:6.3f}  {dialect:30s}  {standard:30s}  {gloss}"
        )

    mean_d = np.mean(distances)
    std_d = np.std(distances)

    lines.append("")
    lines.append(f"Mean normalised distance:  d̄ = {mean_d:.4f}")
    lines.append(f"Standard deviation:        σ = {std_d:.4f}")
    lines.append(f"Min:                       {np.min(distances):.4f}")
    lines.append(f"Max:                       {np.max(distances):.4f}")

    lines.append("")
    lines.append("Interpretation:")
    lines.append(f"  Mean d̄ = {mean_d:.3f} indicates that on average, "
                 f"{mean_d*100:.1f}% of characters differ")
    lines.append(f"  between dialect and standard forms. This is a {'moderate' if mean_d < 0.3 else 'substantial'}")
    lines.append(f"  level of character-level divergence, suggesting that a translation")
    lines.append(f"  model must learn non-trivial morphological and lexical mappings")
    lines.append(f"  beyond simple character substitution.")
    lines.append(f"  The variance (σ={std_d:.3f}) shows that divergence is not uniform —")
    lines.append(f"  some sentences are nearly identical (shared grammar) while others")
    lines.append(f"  differ substantially (lexical replacement: 'po' vs 'chhele').")

    text = "\n".join(lines)
    print(text)

    with open(os.path.join(output_dir, "lev_corpus_stats.txt"), "w") as f:
        f.write("PROBLEM 1.2: CORPUS-LEVEL LEVENSHTEIN DIVERGENCE\n")
        f.write("=" * 120 + "\n\n")
        f.write(text + "\n")

    return mean_d, std_d, distances


def plot_corpus_histogram(
    distances: List[float],
    mean_d: float,
    std_d: float,
    output_dir: str,
):
    """Plot histogram of normalised Levenshtein distances."""
    fig, ax = plt.subplots(figsize=(8, 5))

    ax.hist(distances, bins=10, color="#FF9800", alpha=0.7, edgecolor="white",
            label=f"n={len(distances)} pairs")
    ax.axvline(mean_d, color="red", linestyle="--", linewidth=2,
               label=f"mean = {mean_d:.3f}")
    ax.axvline(mean_d - std_d, color="red", linestyle=":", linewidth=1, alpha=0.5)
    ax.axvline(mean_d + std_d, color="red", linestyle=":", linewidth=1, alpha=0.5,
               label=f"±σ = {std_d:.3f}")

    ax.set_xlabel("Normalised Levenshtein Distance", fontsize=12)
    ax.set_ylabel("Count", fontsize=12)
    ax.set_title("Problem 1.2: Dialect ↔ Standard Bengali Character Divergence",
                 fontsize=13)
    ax.legend(fontsize=10)
    ax.set_xlim(-0.05, 1.05)
    ax.grid(True, alpha=0.3)

    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, "lev_corpus_histogram.png"), dpi=150)
    plt.close(fig)
    print(f"\n  Histogram saved → lev_corpus_histogram.png")


# ═══════════════════════════════════════════════════════════════════════════
# Problem 1.3: Triangle Inequality Proof
# ═══════════════════════════════════════════════════════════════════════════

TRIANGLE_PROOF = r"""
PROBLEM 1.3: TRIANGLE INEQUALITY PROOF
========================================================================

Theorem: For any strings s₁, s₂, s₃,
    d(s₁, s₃) ≤ d(s₁, s₂) + d(s₂, s₃)

where d denotes the Levenshtein edit distance.

Proof (by edit sequence concatenation):

Let E₁₂ be an optimal edit sequence transforming s₁ into s₂,
with |E₁₂| = d(s₁, s₂).

Let E₂₃ be an optimal edit sequence transforming s₂ into s₃,
with |E₂₃| = d(s₂, s₃).

Consider the concatenation E₁₃ = E₁₂ ∘ E₂₃. This composite
sequence first transforms s₁ into s₂ (via E₁₂), then transforms
s₂ into s₃ (via E₂₃). Therefore E₁₃ is a valid edit sequence
transforming s₁ into s₃.

The cost of E₁₃ is:
    |E₁₃| = |E₁₂| + |E₂₃| = d(s₁, s₂) + d(s₂, s₃)

Since d(s₁, s₃) is defined as the MINIMUM cost over all valid
edit sequences transforming s₁ into s₃, and E₁₃ is one such
valid sequence, we have:

    d(s₁, s₃) ≤ |E₁₃| = d(s₁, s₂) + d(s₂, s₃)     ∎

Note: This proof also establishes that Levenshtein distance is a
metric on the space of strings, since it additionally satisfies:
  (i)   d(s, s) = 0  for all s  (identity)
  (ii)  d(s₁, s₂) ≥ 0  for all s₁, s₂  (non-negativity)
  (iii) d(s₁, s₂) = d(s₂, s₁)  (symmetry — each insert ↔ delete)

Numerical verification:

  Let s₁ = "mati" (dialect: earth)
      s₂ = "maati" (intermediate form)
      s₃ = "mrittika" (formal: soil)

  d(s₁, s₂) = 1  (insert 'a')
  d(s₂, s₃) = 6  (multiple edits)
  d(s₁, s₃) = 6

  Check: d(s₁, s₃) = 6 ≤ 1 + 6 = 7 = d(s₁, s₂) + d(s₂, s₃)  ✓
"""


# ═══════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════

def main():
    output_dir = "outputs"
    os.makedirs(output_dir, exist_ok=True)

    print("=" * 70)
    print("A2 PART I: LEVENSHTEIN DISTANCE")
    print("=" * 70)

    # ── Problem 1.1: Implementation + Test Cases ──────────────────
    print("\n" + "─" * 70)
    print("PROBLEM 1.1: Implementation & Test Cases")
    print("─" * 70)

    test_pairs = [
        ("kitten", "sitting", "Standard textbook example"),
        ("intention", "execution", "Standard textbook example"),
        ("mati", "maati", "Bengali transliterated: earth/soil"),
        ("bajare", "hatae", "Bengali: market (standard vs dialect)"),
        ("chhele", "po", "Bengali: son (standard vs dialect)"),
        ("lok", "nok", "Bengali: person (standard vs dialect)"),
    ]

    dp_output = []
    for s1, s2, desc in test_pairs:
        d, dp = levenshtein(s1, s2)
        print(f"\n  d(\"{s1}\", \"{s2}\") = {d}    [{desc}]")

        dp_str = format_dp_matrix(s1, s2, dp)
        print(f"\n{dp_str}")
        dp_output.append(f"\nd(\"{s1}\", \"{s2}\") = {d}    [{desc}]\n\n{dp_str}\n")

    # Save DP matrices
    with open(os.path.join(output_dir, "lev_dp_matrix.txt"), "w") as f:
        f.write("PROBLEM 1.1: DP MATRICES\n")
        f.write("=" * 70 + "\n")
        for block in dp_output:
            f.write(block + "\n")

    # ── Problem 1.2: Corpus-Level Divergence ──────────────────────
    print("\n" + "─" * 70)
    print("PROBLEM 1.2: Corpus-Level Divergence")
    print("─" * 70 + "\n")

    mean_d, std_d, distances = run_corpus_analysis(
        DIALECT_STANDARD_PAIRS, output_dir)
    plot_corpus_histogram(distances, mean_d, std_d, output_dir)

    # ── Problem 1.3: Triangle Inequality ──────────────────────────
    print("\n" + "─" * 70)
    print("PROBLEM 1.3: Triangle Inequality Proof")
    print("─" * 70)

    # Numerical verification
    s1, s2, s3 = "mati", "maati", "mrittika"
    d12, _ = levenshtein(s1, s2)
    d23, _ = levenshtein(s2, s3)
    d13, _ = levenshtein(s1, s3)
    print(f"\n  s₁=\"{s1}\", s₂=\"{s2}\", s₃=\"{s3}\"")
    print(f"  d(s₁,s₂) = {d12}, d(s₂,s₃) = {d23}, d(s₁,s₃) = {d13}")
    print(f"  {d13} ≤ {d12} + {d23} = {d12+d23}  ✓")

    # Additional verification with more triples
    triples = [
        ("ham", "ami", "amar"),
        ("hata", "bajare", "dokan"),
        ("po", "chhele", "balak"),
    ]
    for a, b, c in triples:
        dab, _ = levenshtein(a, b)
        dbc, _ = levenshtein(b, c)
        dac, _ = levenshtein(a, c)
        holds = "✓" if dac <= dab + dbc else "✗"
        print(f"  d(\"{a}\",\"{c}\")={dac} ≤ d(\"{a}\",\"{b}\")={dab} + d(\"{b}\",\"{c}\")={dbc} = {dab+dbc}  {holds}")

    with open(os.path.join(output_dir, "lev_triangle_proof.txt"), "w") as f:
        f.write(TRIANGLE_PROOF)

    print(f"\n  Proof saved → lev_triangle_proof.txt")

    print(f"\n{'='*70}")
    print("PART I COMPLETE")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
