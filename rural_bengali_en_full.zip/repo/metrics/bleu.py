"""
bleu.py
-------
BLEU-1 through BLEU-4 with clipped n-gram counts and brevity penalty.
Supports multiple references.

Assignment 2, Part V, Problem 5.1 — Avnish (Lead Owner)

Implementation follows Papineni et al. (2002):
    BLEU = BP · exp( Σₙ wₙ log pₙ )

where:
    pₙ = clipped n-gram precision
    BP  = min(1, exp(1 - r/c))   brevity penalty
    wₙ  = 1/N  (uniform weights)

Usage:
    from bleu import compute_bleu, bleu_detailed

    # Single reference
    score = compute_bleu(
        hypothesis=["the", "cat", "is", "on", "the", "mat"],
        references=[["the", "cat", "is", "on", "the", "mat"]],
        max_n=4,
    )

    # Multiple references
    score = compute_bleu(
        hypothesis=["the", "cat", "sat", "on", "mat"],
        references=[
            ["the", "cat", "is", "on", "the", "mat"],
            ["there", "is", "a", "cat", "on", "the", "mat"],
        ],
        max_n=4,
    )

    # Detailed breakdown (for report)
    details = bleu_detailed(hypothesis, references, max_n=4)

Authors: Avnish (A2 Part V implementation)
"""

import math
from collections import Counter
from typing import List, Tuple, Dict, Optional


def extract_ngrams(tokens: List[str], n: int) -> Counter:
    """Extract n-grams from a token list and return as Counter."""
    return Counter(
        tuple(tokens[i:i + n])
        for i in range(len(tokens) - n + 1)
    )


def clipped_precision(
    hypothesis: List[str],
    references: List[List[str]],
    n: int,
) -> Tuple[int, int]:
    """
    Compute clipped n-gram precision numerator and denominator.

    For each n-gram in the hypothesis, the clipped count is:
        min(count_hyp(ngram), max over refs of count_ref(ngram))

    Returns
    -------
    (clipped_count, total_count) : numerator and denominator of pₙ
    """
    hyp_ngrams = extract_ngrams(hypothesis, n)

    if not hyp_ngrams:
        return 0, 0

    # For each n-gram, find the maximum count across all references
    max_ref_counts = Counter()
    for ref in references:
        ref_ngrams = extract_ngrams(ref, n)
        for ngram, count in ref_ngrams.items():
            max_ref_counts[ngram] = max(max_ref_counts[ngram], count)

    # Clip each hypothesis n-gram count by the max reference count
    clipped = 0
    for ngram, count in hyp_ngrams.items():
        clipped += min(count, max_ref_counts.get(ngram, 0))

    total = sum(hyp_ngrams.values())
    return clipped, total


def brevity_penalty(
    hypothesis: List[str],
    references: List[List[str]],
) -> float:
    """
    Compute the brevity penalty.

    BP = 1                    if c > r
         exp(1 - r/c)        if c ≤ r

    where c = len(hypothesis), r = effective reference length
    (closest reference length to hypothesis length).
    """
    c = len(hypothesis)
    if c == 0:
        return 0.0

    # Effective reference length: closest to hypothesis length
    ref_lengths = [len(ref) for ref in references]
    r = min(ref_lengths, key=lambda ref_len: (abs(ref_len - c), ref_len))

    if c > r:
        return 1.0
    else:
        return math.exp(1.0 - r / c)


def compute_bleu(
    hypothesis: List[str],
    references: List[List[str]],
    max_n: int = 4,
    weights: Optional[List[float]] = None,
) -> float:
    """
    Compute BLEU score (BLEU-1 through BLEU-max_n).

    Parameters
    ----------
    hypothesis : tokenized hypothesis sentence
    references : list of tokenized reference sentences
    max_n : maximum n-gram order (default: 4 for BLEU-4)
    weights : weights for each n-gram order (default: uniform 1/max_n)

    Returns
    -------
    float : BLEU score in [0, 1]
    """
    if weights is None:
        weights = [1.0 / max_n] * max_n

    assert len(weights) == max_n, f"weights length {len(weights)} != max_n {max_n}"

    if len(hypothesis) == 0:
        return 0.0

    # Compute clipped precisions
    log_precision_sum = 0.0
    for n in range(1, max_n + 1):
        clipped, total = clipped_precision(hypothesis, references, n)
        if total == 0 or clipped == 0:
            return 0.0  # If any pₙ = 0, BLEU = 0
        pn = clipped / total
        log_precision_sum += weights[n - 1] * math.log(pn)

    bp = brevity_penalty(hypothesis, references)
    bleu = bp * math.exp(log_precision_sum)
    return bleu


def bleu_n(
    hypothesis: List[str],
    references: List[List[str]],
    n: int,
) -> float:
    """
    Compute individual BLEU-n score (using only n-gram precision + BP).
    Useful for reporting BLEU-1, BLEU-2, BLEU-3, BLEU-4 separately.
    """
    clipped, total = clipped_precision(hypothesis, references, n)
    if total == 0 or clipped == 0:
        return 0.0
    pn = clipped / total
    bp = brevity_penalty(hypothesis, references)
    return bp * pn


def bleu_detailed(
    hypothesis: List[str],
    references: List[List[str]],
    max_n: int = 4,
) -> Dict:
    """
    Compute BLEU with full breakdown for reporting.

    Returns dict with:
        - bleu: final BLEU-max_n score
        - bleu_1 through bleu_max_n: individual scores
        - precisions: list of (clipped, total, pn) per n
        - brevity_penalty: BP value
        - hyp_length: c
        - ref_length: r (effective)
        - ngrams: dict of n-gram details per n
    """
    c = len(hypothesis)
    ref_lengths = [len(ref) for ref in references]
    r = min(ref_lengths, key=lambda ref_len: (abs(ref_len - c), ref_len))
    bp = brevity_penalty(hypothesis, references)

    precisions = []
    ngram_details = {}

    for n in range(1, max_n + 1):
        clipped, total = clipped_precision(hypothesis, references, n)
        pn = clipped / total if total > 0 else 0.0
        precisions.append((clipped, total, pn))

        # Store individual n-gram matches for detailed reporting
        hyp_ngrams = extract_ngrams(hypothesis, n)
        max_ref_counts = Counter()
        for ref in references:
            ref_ngrams = extract_ngrams(ref, n)
            for ngram, count in ref_ngrams.items():
                max_ref_counts[ngram] = max(max_ref_counts[ngram], count)

        ngram_matches = {}
        for ngram, count in hyp_ngrams.items():
            ref_count = max_ref_counts.get(ngram, 0)
            clip = min(count, ref_count)
            ngram_matches[" ".join(ngram)] = {
                "hyp_count": count,
                "max_ref_count": ref_count,
                "clipped": clip,
            }
        ngram_details[n] = ngram_matches

    result = {
        "bleu": compute_bleu(hypothesis, references, max_n),
        "brevity_penalty": bp,
        "hyp_length": c,
        "ref_length": r,
        "precisions": {
            n: {"clipped": cl, "total": t, "precision": p}
            for n, (cl, t, p) in enumerate(precisions, 1)
        },
        "ngram_details": ngram_details,
    }

    # Individual BLEU-n scores
    for n in range(1, max_n + 1):
        result[f"bleu_{n}"] = bleu_n(hypothesis, references, n)

    return result


def format_detailed_report(details: Dict, max_n: int = 4) -> str:
    """Format bleu_detailed output as a readable report string."""
    lines = []
    lines.append(f"  Hypothesis length (c): {details['hyp_length']}")
    lines.append(f"  Reference length  (r): {details['ref_length']}")
    lines.append(f"  Brevity Penalty (BP):  {details['brevity_penalty']:.4f}")
    lines.append("")

    for n in range(1, max_n + 1):
        p = details["precisions"][n]
        lines.append(
            f"  p{n} = {p['clipped']}/{p['total']} = {p['precision']:.4f}"
        )

    lines.append("")
    for n in range(1, max_n + 1):
        lines.append(f"  BLEU-{n}: {details.get(f'bleu_{n}', 0):.4f}")

    lines.append(f"\n  BLEU-{max_n} (combined): {details['bleu']:.4f}")
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════
# Test cases (per roadmap: test on all three hypotheses vs reference)
# ═══════════════════════════════════════════════════════════════════════════

def run_tests():
    """Run the required test cases from the assignment spec."""
    reference = ["the", "cat", "is", "on", "the", "mat"]

    hypotheses = {
        "Hypothesis 1": ["the", "the", "the", "the", "the", "the", "the"],
        "Hypothesis 2": ["the", "cat", "sat", "on", "the", "mat"],
        "Hypothesis 3": ["the", "cat", "is", "on", "the", "mat"],
    }

    refs = [reference]

    print("=" * 70)
    print("BLEU SCORE TEST CASES")
    print(f"Reference: {' '.join(reference)}")
    print("=" * 70)

    for name, hyp in hypotheses.items():
        print(f"\n{'─'*70}")
        print(f"  {name}: {' '.join(hyp)}")
        print(f"{'─'*70}")

        details = bleu_detailed(hyp, refs, max_n=4)
        report = format_detailed_report(details)
        print(report)

        # Show n-gram details for Hypothesis 1 (per roadmap: detailed calc)
        if name == "Hypothesis 1":
            print(f"\n  Detailed n-gram breakdown:")
            for n in range(1, 5):
                print(f"\n  {n}-grams:")
                for ngram_str, info in details["ngram_details"][n].items():
                    print(
                        f"    '{ngram_str}': "
                        f"hyp={info['hyp_count']}, "
                        f"ref_max={info['max_ref_count']}, "
                        f"clipped={info['clipped']}"
                    )

    # Multi-reference test
    print(f"\n{'='*70}")
    print("MULTI-REFERENCE TEST")
    print("=" * 70)
    multi_refs = [
        ["the", "cat", "is", "on", "the", "mat"],
        ["there", "is", "a", "cat", "on", "the", "mat"],
    ]
    hyp = ["the", "cat", "sat", "on", "the", "mat"]
    print(f"  Hypothesis:   {' '.join(hyp)}")
    for i, ref in enumerate(multi_refs):
        print(f"  Reference {i+1}:  {' '.join(ref)}")

    details = bleu_detailed(hyp, multi_refs, max_n=4)
    print(format_detailed_report(details))


if __name__ == "__main__":
    run_tests()
