"""
eval_divergence.py
==================
Assignment 1 — Task 3 (Intrinsic Evaluation) + Task 4 (Procrustes) + Task 5 (JS Divergence)

Task 3: Avnish leads analysis (overlap metric, histogram)
         Aarav leads hubness (GloVe comparison — added later)
Task 4: Procrustes alignment (Aarav's task, run here as dependency for Task 5)
Task 5: JS divergence (Avnish — Lead Owner)

Usage:
    python eval_divergence.py

Inputs:
    sgns_embeddings_a.npy    — DA-only SGNS embeddings
    sgns_embeddings_b.npy    — DB-only SGNS embeddings
    sgns_embeddings_joint.npy — Joint SGNS embeddings
    sgns_vocab.json          — word2idx, hyperparams

Outputs (outputs/ directory):
    Task 3:
        task3_overlap_histogram.png
        task3_overlap_stats.txt
        task3_hubness_sgns.png
        task3_hubness_table.txt
    Task 4:
        task4_procrustes_R.npy
        task4_shift_table.txt
        task4_sanity_check.txt
    Task 5:
        task5_js_divergence.png    (scatter: Δ vs JS)
        task5_js_top30.txt
        task5_temperature_sensitivity.png
        task5_analysis.txt

Authors: Avnish (Tasks 3 analysis + 5 lead), Aarav (Task 4 lead)
"""

import os
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from collections import Counter
from typing import Dict, List, Tuple, Optional


# ═══════════════════════════════════════════════════════════════════════════
# Load embeddings and vocab
# ═══════════════════════════════════════════════════════════════════════════

def load_all():
    """Load embeddings and vocabulary."""
    E_a = np.load("sgns_embeddings_a.npy")
    E_b = np.load("sgns_embeddings_b.npy")
    E_joint = np.load("sgns_embeddings_joint.npy")

    with open("sgns_vocab.json", "r") as f:
        meta = json.load(f)

    word2idx = meta["word2idx"]
    idx2word = {int(v): k for k, v in word2idx.items()}

    return E_a, E_b, E_joint, word2idx, idx2word, meta


def normalize(E: np.ndarray) -> np.ndarray:
    """L2-normalize embedding matrix."""
    norms = np.linalg.norm(E, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-12)
    return E / norms


def get_top_neighbours(
    E: np.ndarray,
    word_idx: int,
    m: int = 20,
    exclude: set = None,
) -> List[int]:
    """Return indices of top-m nearest neighbours by cosine similarity."""
    if exclude is None:
        exclude = {0, 1}  # PAD, UNK
    sims = E @ E[word_idx]
    sims[word_idx] = -2.0
    for idx in exclude:
        sims[idx] = -2.0
    top = np.argpartition(sims, -m)[-m:]
    top = top[np.argsort(sims[top])[::-1]]
    return list(top)


# ═══════════════════════════════════════════════════════════════════════════
# TASK 3: Intrinsic Evaluation Under Distribution Shift
# ═══════════════════════════════════════════════════════════════════════════

def select_shared_words(
    word2idx: Dict[str, int],
    n: int = 200,
    min_idx: int = 2,  # skip PAD, UNK
) -> List[str]:
    """
    Select n frequent shared words for evaluation.

    Since both corpora share the same vocabulary (built from DA∪DB),
    we pick the top-n most frequent words (by vocab index order,
    which reflects frequency since build_vocab sorts by freq desc).
    """
    # word2idx is sorted by frequency (PAD=0, UNK=1, then freq desc)
    words = sorted(
        [(w, idx) for w, idx in word2idx.items() if idx >= min_idx],
        key=lambda x: x[1],
    )
    return [w for w, _ in words[:n]]


def compute_overlap(
    E_a_norm: np.ndarray,
    E_b_norm: np.ndarray,
    shared_words: List[str],
    word2idx: Dict[str, int],
    m: int = 20,
) -> Tuple[np.ndarray, List[str]]:
    """
    Compute neighbourhood overlap for each shared word.

    Overlap_m(w) = |N_A_m(w) ∩ N_B_m(w)| / m

    Returns array of overlaps and the word list.
    """
    overlaps = []
    for w in shared_words:
        idx = word2idx[w]
        nn_a = set(get_top_neighbours(E_a_norm, idx, m=m))
        nn_b = set(get_top_neighbours(E_b_norm, idx, m=m))
        overlap = len(nn_a & nn_b) / m
        overlaps.append(overlap)
    return np.array(overlaps), shared_words


def compute_hubness(
    E_norm: np.ndarray,
    shared_words: List[str],
    word2idx: Dict[str, int],
    m: int = 20,
) -> Counter:
    """
    Hubness score: H(x) = |{w ∈ S : x ∈ N_m(w)}|

    Count how often each word appears in the top-m neighbourhood
    of any word in the shared set S.
    """
    hub_counts = Counter()
    for w in shared_words:
        idx = word2idx[w]
        nn = get_top_neighbours(E_norm, idx, m=m)
        for n_idx in nn:
            hub_counts[n_idx] += 1
    return hub_counts


def run_task3(
    E_a: np.ndarray,
    E_b: np.ndarray,
    E_joint: np.ndarray,
    word2idx: Dict[str, int],
    idx2word: Dict[int, str],
    output_dir: str,
):
    """Run Task 3: Intrinsic Evaluation."""
    print("\n" + "=" * 70)
    print("TASK 3: Intrinsic Evaluation Under Distribution Shift")
    print("=" * 70)

    # Normalize
    E_a_norm = normalize(E_a)
    E_b_norm = normalize(E_b)
    E_j_norm = normalize(E_joint)

    # Select 200 shared words (or as many as available)
    n_shared = min(200, len(word2idx) - 2)
    shared_words = select_shared_words(word2idx, n=n_shared)
    print(f"\n  Selected {len(shared_words)} shared words for evaluation")
    print(f"  Sample: {shared_words[:10]}")

    # ── Overlap metric ──────────────────────────────────────────────
    m = 20
    overlaps, _ = compute_overlap(E_a_norm, E_b_norm, shared_words, word2idx, m=m)

    mean_overlap = np.mean(overlaps)
    std_overlap = np.std(overlaps)
    median_overlap = np.median(overlaps)

    print(f"\n  Overlap (DA vs DB, top-{m} neighbours):")
    print(f"    Mean:   {mean_overlap:.4f}")
    print(f"    Std:    {std_overlap:.4f}")
    print(f"    Median: {median_overlap:.4f}")
    print(f"    Min:    {np.min(overlaps):.4f}")
    print(f"    Max:    {np.max(overlaps):.4f}")

    # Words with highest and lowest overlap
    sorted_idx = np.argsort(overlaps)
    print(f"\n  Most stable words (highest overlap):")
    for i in sorted_idx[-10:][::-1]:
        print(f"    {shared_words[i]:15s}  overlap={overlaps[i]:.3f}")
    print(f"\n  Most shifted words (lowest overlap):")
    for i in sorted_idx[:10]:
        print(f"    {shared_words[i]:15s}  overlap={overlaps[i]:.3f}")

    # Also compute DA vs Joint and DB vs Joint
    overlaps_aj, _ = compute_overlap(E_a_norm, E_j_norm, shared_words, word2idx, m=m)
    overlaps_bj, _ = compute_overlap(E_b_norm, E_j_norm, shared_words, word2idx, m=m)

    # ── Overlap histogram ───────────────────────────────────────────
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))

    for ax, data, title, color in [
        (axes[0], overlaps, f"DA vs DB", "#FF5722"),
        (axes[1], overlaps_aj, f"DA vs Joint", "#2196F3"),
        (axes[2], overlaps_bj, f"DB vs Joint", "#4CAF50"),
    ]:
        ax.hist(data, bins=20, color=color, alpha=0.7, edgecolor="white")
        ax.axvline(np.mean(data), color="black", linestyle="--", linewidth=1.5,
                   label=f"mean={np.mean(data):.3f}")
        ax.set_xlabel(f"Overlap (top-{m})", fontsize=11)
        ax.set_ylabel("Count", fontsize=11)
        ax.set_title(title, fontsize=13)
        ax.legend(fontsize=10)
        ax.set_xlim(-0.05, 1.05)

    fig.suptitle("Task 3: Neighbourhood Overlap Under Distribution Shift (SGNS)",
                 fontsize=14, fontweight="bold")
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, "task3_overlap_histogram.png"), dpi=150)
    plt.close(fig)
    print(f"\n  Histogram saved → task3_overlap_histogram.png")

    # ── Hubness analysis (SGNS only — GloVe comparison is Aarav's) ──
    print(f"\n  Computing hubness scores...")
    hubs_a = compute_hubness(E_a_norm, shared_words, word2idx, m=m)
    hubs_b = compute_hubness(E_b_norm, shared_words, word2idx, m=m)
    hubs_j = compute_hubness(E_j_norm, shared_words, word2idx, m=m)

    # Count extreme hubs (appear in >5% of neighbourhoods)
    threshold = len(shared_words) * 0.05
    extreme_a = sum(1 for _, c in hubs_a.items() if c > threshold)
    extreme_b = sum(1 for _, c in hubs_b.items() if c > threshold)
    extreme_j = sum(1 for _, c in hubs_j.items() if c > threshold)

    print(f"    Extreme hubs (>{threshold:.0f} appearances):")
    print(f"      DA:    {extreme_a}")
    print(f"      DB:    {extreme_b}")
    print(f"      Joint: {extreme_j}")

    # Plot top-20 hubs
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    for ax, hubs, title, color in [
        (axes[0], hubs_a, "DA (dialect)", "#FF5722"),
        (axes[1], hubs_b, "DB (standard)", "#4CAF50"),
        (axes[2], hubs_j, "Joint", "#2196F3"),
    ]:
        top20 = hubs.most_common(20)
        words = [idx2word.get(idx, "?") for idx, _ in top20]
        counts = [c for _, c in top20]
        ax.barh(range(len(words)), counts, color=color, alpha=0.7)
        ax.set_yticks(range(len(words)))
        ax.set_yticklabels(words, fontsize=8)
        ax.invert_yaxis()
        ax.set_xlabel("Hub count H(x)", fontsize=11)
        ax.set_title(title, fontsize=12)

    fig.suptitle(f"Task 3: Top-20 Hubs (SGNS, m={m})", fontsize=14, fontweight="bold")
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, "task3_hubness_sgns.png"), dpi=150)
    plt.close(fig)
    print(f"  Hubness chart saved → task3_hubness_sgns.png")

    # ── Save stats ──────────────────────────────────────────────────
    with open(os.path.join(output_dir, "task3_overlap_stats.txt"), "w") as f:
        f.write("TASK 3: INTRINSIC EVALUATION — NEIGHBOURHOOD OVERLAP\n")
        f.write("=" * 70 + "\n\n")
        f.write(f"Shared words evaluated: {len(shared_words)}\n")
        f.write(f"Neighbourhood size m: {m}\n\n")

        f.write(f"DA vs DB:    mean={np.mean(overlaps):.4f}  std={np.std(overlaps):.4f}  "
                f"median={np.median(overlaps):.4f}\n")
        f.write(f"DA vs Joint: mean={np.mean(overlaps_aj):.4f}  std={np.std(overlaps_aj):.4f}  "
                f"median={np.median(overlaps_aj):.4f}\n")
        f.write(f"DB vs Joint: mean={np.mean(overlaps_bj):.4f}  std={np.std(overlaps_bj):.4f}  "
                f"median={np.median(overlaps_bj):.4f}\n\n")

        f.write("Most stable words (highest DA vs DB overlap):\n")
        for i in sorted_idx[-15:][::-1]:
            f.write(f"  {shared_words[i]:15s}  overlap={overlaps[i]:.3f}\n")
        f.write("\nMost shifted words (lowest DA vs DB overlap):\n")
        for i in sorted_idx[:15]:
            f.write(f"  {shared_words[i]:15s}  overlap={overlaps[i]:.3f}\n")

        f.write(f"\nPer-word overlaps:\n")
        for w, ov in zip(shared_words, overlaps):
            f.write(f"  {w:15s}  {ov:.4f}\n")

    with open(os.path.join(output_dir, "task3_hubness_table.txt"), "w") as f:
        f.write("TASK 3: HUBNESS ANALYSIS (SGNS)\n")
        f.write("=" * 70 + "\n\n")
        for label, hubs in [("DA", hubs_a), ("DB", hubs_b), ("Joint", hubs_j)]:
            f.write(f"\nTop-20 hubs — {label}:\n")
            for idx, count in hubs.most_common(20):
                f.write(f"  {idx2word.get(idx, '?'):15s}  H={count}\n")

    return overlaps, shared_words


# ═══════════════════════════════════════════════════════════════════════════
# TASK 4: Procrustes Alignment (run as dependency for Task 5)
# ═══════════════════════════════════════════════════════════════════════════

def procrustes_align(
    E_a: np.ndarray,
    E_b: np.ndarray,
    word2idx: Dict[str, int],
    idx2word: Dict[int, str],
    n_anchors: int = 500,
    output_dir: str = "outputs",
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Procrustes alignment: find R* = argmin ||X R - Y||_F.

    Per roadmap (Task 4):
        - Anchor set A = top most-frequent shared words, excluding stopwords
        - X = [e_A_w]_{w∈A}, Y = [e_B_w]_{w∈A}
        - SVD: X^T Y = U Σ V^T, R* = U V^T
        - If det(R*) = -1, flip last column of U

    Returns (E_a_aligned, R_star, shift_scores)
    """
    print("\n" + "=" * 70)
    print("TASK 4: Procrustes Alignment (dependency for Task 5)")
    print("=" * 70)

    # Normalize
    E_a_norm = normalize(E_a)
    E_b_norm = normalize(E_b)

    # Select anchors: top-n_anchors words by index (= by frequency)
    # Skip PAD (0) and UNK (1)
    anchor_indices = list(range(2, min(2 + n_anchors, len(word2idx))))
    print(f"  Anchor set: {len(anchor_indices)} words")

    # Stack anchor embeddings
    X = E_a_norm[anchor_indices]  # (n_anchors, d)
    Y = E_b_norm[anchor_indices]  # (n_anchors, d)

    # SVD: X^T Y = U Σ V^T
    M = X.T @ Y
    U, S, Vt = np.linalg.svd(M)
    R_star = U @ Vt

    # Check for reflection
    if np.linalg.det(R_star) < 0:
        print("  Reflection detected — flipping last column of U")
        U[:, -1] *= -1
        R_star = U @ Vt

    print(f"  det(R*) = {np.linalg.det(R_star):.6f}")

    # Align E_a
    E_a_aligned = E_a_norm @ R_star

    # Compute shift scores: Δ(w) = 1 - cos(e_A_w R*, e_B_w)
    # After alignment, both are normalized, so cos = dot product
    cos_sims = np.sum(E_a_aligned * E_b_norm, axis=1)
    shift_scores = 1.0 - cos_sims

    # Sanity check: anchor words should have low average Δ
    anchor_shifts = shift_scores[anchor_indices]
    print(f"\n  Sanity check — anchor words:")
    print(f"    Mean Δ:   {np.mean(anchor_shifts):.6f}")
    print(f"    Median Δ: {np.median(anchor_shifts):.6f}")
    print(f"    Max Δ:    {np.max(anchor_shifts):.6f}")

    # Top-50 shifting words
    valid_indices = [i for i in range(2, len(shift_scores))]
    sorted_by_shift = sorted(valid_indices, key=lambda i: -shift_scores[i])

    print(f"\n  Top-20 most shifted words:")
    for rank, idx in enumerate(sorted_by_shift[:20], 1):
        w = idx2word.get(idx, "?")
        print(f"    {rank:3d}. {w:15s}  Δ={shift_scores[idx]:.4f}")

    # Save
    np.save(os.path.join(output_dir, "task4_procrustes_R.npy"), R_star)

    with open(os.path.join(output_dir, "task4_shift_table.txt"), "w") as f:
        f.write("TASK 4: TOP-50 MOST SHIFTED WORDS (Procrustes Alignment)\n")
        f.write("=" * 70 + "\n")
        f.write(f"Δ(w) = 1 - cos(e_A_w · R*, e_B_w)\n\n")
        for rank, idx in enumerate(sorted_by_shift[:50], 1):
            w = idx2word.get(idx, "?")
            f.write(f"  {rank:3d}. {w:20s}  Δ={shift_scores[idx]:.4f}\n")

    with open(os.path.join(output_dir, "task4_sanity_check.txt"), "w") as f:
        f.write("TASK 4: PROCRUSTES SANITY CHECK\n")
        f.write("=" * 70 + "\n")
        f.write(f"Anchors: {len(anchor_indices)}\n")
        f.write(f"det(R*): {np.linalg.det(R_star):.6f}\n")
        f.write(f"Anchor mean Δ:   {np.mean(anchor_shifts):.6f}\n")
        f.write(f"Anchor median Δ: {np.median(anchor_shifts):.6f}\n")
        f.write(f"Anchor max Δ:    {np.max(anchor_shifts):.6f}\n")
        f.write(f"\nQuality gate: mean Δ < 0.05 → {'PASS' if np.mean(anchor_shifts) < 0.05 else 'FAIL'}\n")

    return E_a_aligned, R_star, shift_scores


# ═══════════════════════════════════════════════════════════════════════════
# TASK 5: Jensen-Shannon Divergence of Neighbourhood Distributions
# ═══════════════════════════════════════════════════════════════════════════

def build_neighbourhood_distribution(
    E: np.ndarray,
    word_idx: int,
    K: int = 300,
    tau: float = 10.0,
    eps: float = 1e-12,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Build softmax neighbourhood distribution for word w over top-K neighbours.

    P_w(x) = exp(τ · cos(e_w, e_x)) / Σ_{y ∈ V_K(w)} exp(τ · cos(e_w, e_y))

    Returns (distribution, neighbour_indices) both of length K.
    """
    sims = E @ E[word_idx]
    sims[word_idx] = -2.0
    sims[0] = -2.0  # PAD
    sims[1] = -2.0  # UNK

    # Top-K neighbours
    if K >= len(sims):
        K = len(sims) - 3  # exclude self, PAD, UNK
    top_k = np.argpartition(sims, -K)[-K:]

    # Softmax with temperature
    top_sims = sims[top_k] * tau
    top_sims -= np.max(top_sims)  # numerical stability
    exp_sims = np.exp(top_sims)
    dist = exp_sims / (np.sum(exp_sims) + eps)

    return dist, top_k


def js_divergence(
    P: np.ndarray,
    Q: np.ndarray,
    P_indices: np.ndarray,
    Q_indices: np.ndarray,
    eps: float = 1e-12,
) -> float:
    """
    Compute Jensen-Shannon divergence between two neighbourhood distributions.

    JS(P || Q) = 0.5 KL(P || M) + 0.5 KL(Q || M),  M = (P + Q) / 2

    P and Q may have different support (different top-K neighbours),
    so we compute over the union of their supports.
    """
    # Build distributions over union of supports
    union_indices = np.union1d(P_indices, Q_indices)
    n = len(union_indices)

    p_full = np.full(n, eps)
    q_full = np.full(n, eps)

    idx_map = {idx: i for i, idx in enumerate(union_indices)}
    for i, idx in enumerate(P_indices):
        if idx in idx_map:
            p_full[idx_map[idx]] = P[i]
    for i, idx in enumerate(Q_indices):
        if idx in idx_map:
            q_full[idx_map[idx]] = Q[i]

    # Renormalize
    p_full /= p_full.sum()
    q_full /= q_full.sum()

    # M = (P + Q) / 2
    m = (p_full + q_full) / 2.0

    # KL(P || M) + KL(Q || M)
    kl_pm = np.sum(p_full * np.log(p_full / (m + eps) + eps))
    kl_qm = np.sum(q_full * np.log(q_full / (m + eps) + eps))

    return 0.5 * kl_pm + 0.5 * kl_qm


def run_task5(
    E_a_aligned: np.ndarray,
    E_b_norm: np.ndarray,
    shift_scores: np.ndarray,
    word2idx: Dict[str, int],
    idx2word: Dict[int, str],
    output_dir: str,
):
    """Run Task 5: JS Divergence of Neighbourhood Distributions."""
    print("\n" + "=" * 70)
    print("TASK 5: Jensen-Shannon Divergence")
    print("=" * 70)

    K = 300  # per roadmap
    valid_indices = [i for i in range(2, len(word2idx))]

    # Cap K to available vocab
    effective_K = min(K, len(valid_indices) - 1)
    print(f"  K={effective_K} (capped from {K} due to vocab size {len(valid_indices)})")

    # ── Temperature sensitivity ────────────────────────────────────
    taus = [5, 10, 20]
    tau_results = {}

    for tau in taus:
        print(f"\n  τ = {tau}:")
        js_scores = np.zeros(len(word2idx))

        for idx in valid_indices:
            P_a, P_a_idx = build_neighbourhood_distribution(
                E_a_aligned, idx, K=effective_K, tau=tau)
            P_b, P_b_idx = build_neighbourhood_distribution(
                E_b_norm, idx, K=effective_K, tau=tau)
            js_scores[idx] = js_divergence(P_a, P_b, P_a_idx, P_b_idx)

        valid_js = js_scores[valid_indices]
        print(f"    Mean JS:   {np.mean(valid_js):.6f}")
        print(f"    Median JS: {np.median(valid_js):.6f}")
        print(f"    Max JS:    {np.max(valid_js):.6f}")
        tau_results[tau] = js_scores.copy()

    # Use τ=10 as default (per roadmap recommendation)
    js_default = tau_results[10]

    # ── Top-30 by JS ───────────────────────────────────────────────
    sorted_by_js = sorted(valid_indices, key=lambda i: -js_default[i])

    print(f"\n  Top-30 words by JS divergence (τ=10):")
    for rank, idx in enumerate(sorted_by_js[:30], 1):
        w = idx2word.get(idx, "?")
        print(f"    {rank:3d}. {w:15s}  JS={js_default[idx]:.4f}  Δ={shift_scores[idx]:.4f}")

    # ── Scatter plot: Δ(w) vs JS(w) ───────────────────────────────
    fig, ax = plt.subplots(figsize=(10, 8))

    delta_vals = shift_scores[valid_indices]
    js_vals = js_default[valid_indices]
    words_list = [idx2word.get(i, "?") for i in valid_indices]

    ax.scatter(delta_vals, js_vals, alpha=0.4, s=15, c="#2196F3", edgecolor="none")

    # Label top-15 by JS
    top_js_idx = sorted(range(len(js_vals)), key=lambda i: -js_vals[i])[:15]
    for i in top_js_idx:
        ax.annotate(words_list[i], (delta_vals[i], js_vals[i]),
                     fontsize=7, alpha=0.8,
                     xytext=(5, 5), textcoords='offset points')

    # Label top disagreements (high Δ, low JS or vice versa)
    # Correlation
    corr = np.corrcoef(delta_vals, js_vals)[0, 1]
    ax.set_xlabel("Δ(w) — Procrustes Shift Score", fontsize=12)
    ax.set_ylabel("JS(P_A || P_B) — Neighbourhood Divergence", fontsize=12)
    ax.set_title(f"Task 5: Procrustes Shift vs JS Divergence (r={corr:.3f}, τ=10)",
                 fontsize=14)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, "task5_js_divergence.png"), dpi=150)
    plt.close(fig)
    print(f"\n  Scatter plot saved → task5_js_divergence.png")

    # ── Temperature sensitivity plot ──────────────────────────────
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    for ax, tau in zip(axes, taus):
        js_tau = tau_results[tau][valid_indices]
        ax.hist(js_tau, bins=30, color="#FF9800", alpha=0.7, edgecolor="white")
        ax.set_xlabel("JS Divergence", fontsize=11)
        ax.set_ylabel("Count", fontsize=11)
        ax.set_title(f"τ = {tau}  (mean={np.mean(js_tau):.4f})", fontsize=12)
    fig.suptitle("Task 5: Temperature Sensitivity of JS Divergence",
                 fontsize=14, fontweight="bold")
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, "task5_temperature_sensitivity.png"), dpi=150)
    plt.close(fig)
    print(f"  Temperature plot saved → task5_temperature_sensitivity.png")

    # ── Disagreement analysis ─────────────────────────────────────
    # Find words where Δ and JS disagree
    delta_rank = np.argsort(-delta_vals)
    js_rank = np.argsort(-js_vals)

    # Build rank lookup
    delta_rank_map = {i: r for r, i in enumerate(delta_rank)}
    js_rank_map = {i: r for r, i in enumerate(js_rank)}

    # Words with high Δ rank but low JS rank (and vice versa)
    disagreements = []
    for i in range(len(valid_indices)):
        d_rank = delta_rank_map[i]
        j_rank = js_rank_map[i]
        disagreements.append((i, d_rank, j_rank, abs(d_rank - j_rank)))

    disagreements.sort(key=lambda x: -x[3])

    # ── Save outputs ──────────────────────────────────────────────
    with open(os.path.join(output_dir, "task5_js_top30.txt"), "w") as f:
        f.write("TASK 5: TOP-30 WORDS BY JS DIVERGENCE\n")
        f.write("=" * 70 + "\n")
        f.write(f"τ = 10, K = {effective_K}\n")
        f.write(f"Correlation(Δ, JS) = {corr:.4f}\n\n")

        f.write(f"{'Rank':>4s}  {'Word':15s}  {'JS':>8s}  {'Δ':>8s}\n")
        f.write(f"{'─'*4}  {'─'*15}  {'─'*8}  {'─'*8}\n")
        for rank, idx in enumerate(sorted_by_js[:30], 1):
            w = idx2word.get(idx, "?")
            f.write(f"{rank:4d}  {w:15s}  {js_default[idx]:8.4f}  {shift_scores[idx]:8.4f}\n")

    with open(os.path.join(output_dir, "task5_analysis.txt"), "w") as f:
        f.write("TASK 5: ANALYSIS\n")
        f.write("=" * 70 + "\n\n")

        f.write(f"Correlation between Δ(w) and JS(P_A || P_B): r = {corr:.4f}\n\n")

        f.write("Temperature sensitivity:\n")
        for tau in taus:
            js_tau = tau_results[tau][valid_indices]
            f.write(f"  τ={tau:2d}: mean={np.mean(js_tau):.6f}  "
                    f"std={np.std(js_tau):.6f}  "
                    f"max={np.max(js_tau):.6f}\n")

        f.write(f"\nTop-15 disagreements (|Δ_rank - JS_rank|):\n")
        f.write(f"{'Word':15s}  {'Δ_rank':>7s}  {'JS_rank':>7s}  {'|diff|':>7s}  "
                f"{'Δ':>8s}  {'JS':>8s}\n")
        f.write(f"{'─'*15}  {'─'*7}  {'─'*7}  {'─'*7}  {'─'*8}  {'─'*8}\n")
        for i, d_r, j_r, diff in disagreements[:15]:
            w = words_list[i]
            f.write(f"{w:15s}  {d_r:7d}  {j_r:7d}  {diff:7d}  "
                    f"{delta_vals[i]:8.4f}  {js_vals[i]:8.4f}\n")

        f.write(f"\nInterpretation:\n")
        f.write(f"  Δ measures point-wise geometric shift after Procrustes alignment.\n")
        f.write(f"  JS measures divergence of the full neighbourhood distribution.\n")
        f.write(f"  When Δ is high but JS is low: the word moved but its local\n")
        f.write(f"  neighbourhood structure is preserved (rigid translation in space).\n")
        f.write(f"  When JS is high but Δ is low: the word stayed put but its\n")
        f.write(f"  neighbours changed — different contextual associations.\n")

    return js_default


# ═══════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════

def main():
    output_dir = "outputs"
    os.makedirs(output_dir, exist_ok=True)

    E_a, E_b, E_joint, word2idx, idx2word, meta = load_all()
    print(f"Loaded: V={len(word2idx)}, d={E_a.shape[1]}")

    # Task 3
    overlaps, shared_words = run_task3(E_a, E_b, E_joint, word2idx, idx2word, output_dir)

    # Task 4 (dependency for Task 5)
    E_b_norm = normalize(E_b)
    E_a_aligned, R_star, shift_scores = procrustes_align(
        E_a, E_b, word2idx, idx2word,
        n_anchors=min(500, len(word2idx) - 2),
        output_dir=output_dir,
    )

    # Task 5
    js_scores = run_task5(E_a_aligned, E_b_norm, shift_scores, word2idx, idx2word, output_dir)

    print(f"\n{'='*70}")
    print("ALL TASKS COMPLETE")
    print(f"{'='*70}")
    print(f"  Outputs in: {output_dir}/")


if __name__ == "__main__":
    main()
